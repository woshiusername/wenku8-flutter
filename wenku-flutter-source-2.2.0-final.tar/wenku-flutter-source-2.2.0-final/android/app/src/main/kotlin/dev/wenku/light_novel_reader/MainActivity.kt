package dev.wenku.light_novel_reader

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.content.Intent
import android.net.Uri
import android.util.Base64
import android.view.WindowManager
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import java.util.zip.GZIPInputStream
import org.mewx.wenku8.api.TokenManager

class MainActivity : FlutterActivity() {
    private val executor = Executors.newFixedThreadPool(4)
    private val prefs by lazy { getSharedPreferences("wenku_session", MODE_PRIVATE) }
    private val sessionLock = Any()

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "wenku/native").setMethodCallHandler { call, result ->
            when (call.method) {
                "storagePath" -> result.success(filesDir.absolutePath)
                "hasSession" -> result.success(!prefs.getString("session", "").isNullOrEmpty())
                "clearSession" -> { prefs.edit().remove("session").apply(); result.success(null) }
                "openUrl" -> {
                    val url = call.argument<String>("url") ?: ""
                    if (url.startsWith("https://")) {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        result.success(null)
                    } else result.error("URL", "无效地址", null)
                }
                "keepAwake" -> {
                    if (call.argument<Boolean>("enabled") == true) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    result.success(null)
                }
                "encodeGbk" -> {
                    result.success(Base64.encodeToString(URLEncoder.encode(call.argument<String>("text") ?: "", "GBK").toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
                }
                "request" -> executor.execute {
                    try {
                        val action = call.argument<String>("action") ?: throw IllegalArgumentException("缺少请求")
                        val response = request(action)
                        runOnUiThread { result.success(response) }
                    } catch (e: Exception) {
                        runOnUiThread { result.error("NETWORK", e.message ?: "连接失败", null) }
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun request(action: String): Map<String, Any> {
        val conn = URL("https://wenku8-relay.mewx.org/").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 12000
            conn.readTimeout = 20000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            conn.setRequestProperty("Accept-Encoding", "gzip")
            // Match the original Android transport; some server rules reject generic clients.
            conn.setRequestProperty("User-Agent", System.getProperty("http.agent") ?: "Dalvik/2.1.0")
            val cookie = synchronized(sessionLock) { prefs.getString("session", "") ?: "" }
            if (cookie.isNotEmpty()) conn.setRequestProperty("Cookie", "PHPSESSID=$cookie")
            val version = TokenManager.getMagicVersionCpp("1.30")
            val encoded = Base64.encodeToString(action.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val body = "&appver=$version&request=$encoded&timetoken=${System.currentTimeMillis()}"
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val status = conn.responseCode
            val input = if (status in 200..299) conn.inputStream else conn.errorStream
            val stream = if (conn.contentEncoding?.contains("gzip") == true) GZIPInputStream(input) else input
            val text = stream?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
            if (status in 200..299) {
                conn.headerFields.filter { it.key?.equals("Set-Cookie", true) == true }.values.flatten().forEach { value ->
                    val match = Regex("PHPSESSID=([^;]*)").find(value)
                    if (match != null) synchronized(sessionLock) { prefs.edit().putString("session", match.groupValues[1]).apply() }
                }
            }
            return mapOf("status" to status, "text" to text)
        } finally { conn.disconnect() }
    }
}
