package org.mewx.wenku8.api;

/** Compatibility entry point for the native library supplied with Wenku8 1.30. */
public final class TokenManager {
    static { System.loadLibrary("cpp"); }
    public static native String getMagicVersionCpp(String version);
}
