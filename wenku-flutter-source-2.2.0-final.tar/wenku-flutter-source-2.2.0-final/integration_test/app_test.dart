import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:light_novel_reader/api.dart';
import 'package:light_novel_reader/main.dart';
import 'package:light_novel_reader/store.dart';
import 'package:light_novel_reader/screens.dart';

class OfflineApi extends WenkuApi {
  int requests = 0;
  @override
  Future<String> request(String action, {bool retry = true}) async {
    requests++;
    throw const WenkuException('offline test');
  }
}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  testWidgets('Android native transport and full reading flow', (tester) async {
    final store = ReaderStore(WenkuApi());
    await store.init();
    await tester.pumpWidget(WenkuApp(store));
    await tester.pump(const Duration(seconds: 2));
    final api = store.api;
    final books = await api.list('lastupdate', 1);
    expect(books.books, isNotEmpty);
    expect(books.pages, greaterThan(1));
    expect(books.books.first.title, isNot(contains('\uFFFD')));
    final page2 = await api.list('lastupdate', 2);
    expect(page2.books.first.id, isNot(books.books.first.id));
    final rank = await api.list('allvisit', 1);
    expect(rank.books.first.hits, greaterThan(0));
    final search = await api.search('刀剑神域', 'articlename');
    expect(search.books.any((n) => n.id == 471), true);
    final author = await api.search('川原砾', 'author');
    expect(author.books, isNotEmpty);
    final novel = await api.detail(1);
    expect(novel.title, '文学少女');
    expect(novel.author, '野村美月');
    expect(await api.intro(1), isNotEmpty);
    final catalog = await api.catalog(1, refresh: true);
    expect(catalog.length, greaterThan(100));
    final text = await api.text(1, catalog.first.id, refresh: true);
    expect(text.length, greaterThan(500));
    expect(text, isNot(contains('\uFFFD')));
    final secondText = await api.text(1, catalog[1].id, refresh: true);
    expect(secondText, isNot(text));
    final image = await api.image(novel.cover);
    expect(await image.length(), greaterThan(1000));
    final reviews = await api.reviews(1, 1);
    expect(reviews, isNotEmpty);
    expect(await api.replies(reviews.first.id, 1), isNotEmpty);
    api.language = 1;
    expect((await api.detail(1)).title, '文學少女');
    api.language = 0;
    debugPrint(
      'LIVE PASS: updates, page 2, ranking, title/author search, meta, intro, catalog, two chapters, cover, reviews/replies, traditional Chinese',
    );

    final offline = OfflineApi()..cache = api.cache;
    expect(await offline.text(1, catalog.first.id), text);
    expect((await offline.catalog(1)).length, catalog.length);
    expect(offline.requests, 0);
    debugPrint('OFFLINE PASS: cached catalog and chapter need no network request');

    await tester.pumpWidget(WenkuApp(store));
    await tester.pumpAndSettle(const Duration(seconds: 1));
    expect(find.text('书库'), findsWidgets);
    expect(tester.takeException(), isNull);
    final context = tester.element(find.byType(HomeScreen));
    showBook(context, store, novel);
    await tester.pumpAndSettle(const Duration(seconds: 1));
    await tester.tap(find.text('加入书架'));
    await tester.pumpAndSettle();
    expect(store.contains(1), true);
    await tester.tap(find.byKey(const ValueKey('start_reading')));
    await tester.pumpAndSettle(const Duration(seconds: 1));
    expect(find.byKey(ValueKey('chapter_${catalog.first.id}')), findsOneWidget);
    await tester.drag(find.byType(ListView).first, const Offset(0, -500));
    await tester.pumpAndSettle(const Duration(seconds: 1));
    expect((store.record(1)?['offset'] as num).toDouble(), greaterThan(0));
    await tester.tap(find.byKey(const ValueKey('next_chapter')));
    await tester.pumpAndSettle(const Duration(seconds: 1));
    expect(find.byKey(ValueKey('chapter_${catalog[1].id}')), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('previous_chapter')));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    debugPrint(
      'UI PASS: detail, local shelf, reader, saved offset, next/previous chapter',
    );
    final path = await WenkuApi.channel.invokeMethod<String>('storagePath');
    await File('$path/runtime-validation.txt').writeAsString(
      'PASS: server, all tested read endpoints, cached offline reading, detail/shelf/reader/chapters\n',
    );
  });
}
