param([switch]$Test)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\env.ps1"
$source = Split-Path -Parent $PSScriptRoot
$stage = 'D:\wenku8_flutter_build_20261007'
if (!(Test-Path -LiteralPath "$stage\.wenku-staging")) { throw 'The project build staging marker is missing.' }
$tools = "$stage\.tools\msvc"
$compiler = Get-ChildItem -LiteralPath "$tools\VC\Tools\MSVC" -Directory | Sort-Object Name -Descending | Select-Object -First 1
$sdk = "$tools\Windows Kits\10"
$sdkVersion = (Get-ChildItem -LiteralPath "$sdk\Include" -Directory | Sort-Object Name -Descending | Select-Object -First 1).Name
$compilerBin = "$($compiler.FullName)\bin\HostX64\x64"
$sdkBin = "$sdk\bin\$sdkVersion\x64"
$cmake = 'D:\fluter\.tools\android-sdk\cmake\3.22.1\bin\cmake.exe'
$ninja = 'D:\fluter\.tools\android-sdk\cmake\3.22.1\bin\ninja.exe'
$env:INCLUDE = "$($compiler.FullName)\include;$sdk\Include\$sdkVersion\ucrt;$sdk\Include\$sdkVersion\um;$sdk\Include\$sdkVersion\shared;$sdk\Include\$sdkVersion\winrt"
$env:LIB = "$($compiler.FullName)\lib\x64;$sdk\Lib\$sdkVersion\ucrt\x64;$sdk\Lib\$sdkVersion\um\x64"
$env:PATH = "$compilerBin;$sdkBin;$env:PATH"
robocopy $source $stage /E /XD build .dart_tool .gradle screenshots dist /XF local.properties *.iml /NFL /NDL /NJH /NJS /NP
if ($LASTEXITCODE -ge 8) { throw 'Source synchronization failed.' }
Push-Location -LiteralPath $stage
try {
    $pubspec=Get-Content -LiteralPath 'pubspec.yaml' -Raw
    $pubspec=$pubspec -replace '(?m)^  integration_test:\r?\n    sdk: flutter\r?\n',''
    Set-Content -LiteralPath 'pubspec.yaml' -Value $pubspec -Encoding utf8
    flutter pub get --offline
    if ($LASTEXITCODE -ne 0) { throw 'Dependency resolution failed.' }
    if ($Test) { flutter test test --no-pub; if ($LASTEXITCODE -ne 0) { throw 'Tests failed.' } }
    # Flutter writes its ephemeral configuration before checking installed VS.
    # Portable MSVC is used directly with Ninja for the actual native build.
    flutter build windows --release --no-pub
    if (!(Test-Path -LiteralPath 'windows\flutter\ephemeral\generated_config.cmake')) { throw 'Flutter configuration was not generated.' }
    $cxx = "$compilerBin/cl.exe".Replace('\','/')
    $rc = "$sdkBin/rc.exe".Replace('\','/')
    $mt = "$sdkBin/mt.exe".Replace('\','/')
    $ninjaPath = $ninja.Replace('\','/')
    $bundle = "$stage/build/windows-desktop/runner".Replace('\','/')
    & $cmake -S windows -B build/windows-desktop -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_INSTALL_PREFIX=$bundle" "-DCMAKE_CXX_COMPILER=$cxx" "-DCMAKE_MAKE_PROGRAM=$ninjaPath" "-DCMAKE_RC_COMPILER=$rc" "-DCMAKE_MT=$mt"
    if ($LASTEXITCODE -ne 0) { throw 'CMake configuration failed.' }
    & $cmake --build build/windows-desktop --target install --parallel 4
    if ($LASTEXITCODE -ne 0) { throw 'Windows build failed.' }
    $dist = Join-Path $source 'dist\windows\文库'
    New-Item -ItemType Directory -Path $dist -Force | Out-Null
    $runner = "$stage\build\windows-desktop\runner"
    Get-ChildItem -LiteralPath $runner -File | Where-Object Extension -In '.exe','.dll' | Copy-Item -Destination $dist -Force
    robocopy "$runner\data" "$dist\data" /E /NFL /NDL /NJH /NJS /NP
    if ($LASTEXITCODE -ge 8) { throw 'Windows distribution copy failed.' }
    $redist = Get-ChildItem -LiteralPath "$tools\VC\Redist\MSVC" -Directory | Where-Object Name -Match '^\d+\.' | Sort-Object Name -Descending | Select-Object -First 1
    Get-ChildItem -LiteralPath "$($redist.FullName)\x64\Microsoft.VC143.CRT" -Filter '*.dll' | Copy-Item -Destination $dist -Force
    Move-Item -LiteralPath "$dist\wenku.exe" -Destination "$dist\文库.exe" -Force
} finally { Pop-Location }
