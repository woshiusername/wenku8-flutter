import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:light_novel_reader/api.dart';
import 'package:light_novel_reader/windows_backend.dart';

class LiveNetwork extends HttpOverrides {}

void main() {
  test(
    'Windows production transport connects independently and reads real data',
    () async {
      final dir = await Directory.systemTemp.createTemp('wenku-windows-live-');
      final report = <String, dynamic>{};
      await HttpOverrides.runWithHttpOverrides(() async {
        final backend = WindowsBackend(dataDirectory: dir);
        WenkuApi.desktop = backend;
        final api = WenkuApi();
        await api.init();
        final novel = await api.detail(1);
        expect(novel.title, '文学少女');
        report['metadata'] = true;
        final list = await api.list('lastupdate', 1);
        expect(list.books, isNotEmpty);
        report['updates'] = list.books.length;
        final next = await api.list('lastupdate', 2);
        expect(next.books.first.id, isNot(list.books.first.id));
        report['pagination'] = true;
        report['rankings'] = (await api.list('allvisit', 1)).books.length;
        expect(
          (await api.search(
            'SAO',
            'articlename',
          )).books.any((n) => n.id == 471),
          true,
        );
        report['title_search'] = true;
        expect((await api.search('川原砾', 'author')).books, isNotEmpty);
        report['author_search'] = true;
        expect(await api.intro(1), isNotEmpty);
        report['intro'] = true;
        final catalog = await api.catalog(1, refresh: true);
        expect(catalog.length, greaterThan(100));
        report['catalog'] = catalog.length;
        final text = await api.text(1, catalog.first.id, refresh: true);
        expect(text.length, greaterThan(500));
        report['chapter_characters'] = text.length;
        expect(await api.text(1, catalog.first.id), text);
        report['cached_reading'] = true;
        final reviews = await api.reviews(1, 1);
        expect(reviews, isNotEmpty);
        report['reviews'] = reviews.length;
        expect(await api.replies(reviews.first.id, 1), isNotEmpty);
        report['replies'] = true;
        expect(
          await (await api.image(novel.cover)).length(),
          greaterThan(1000),
        );
        report['cover'] = true;
        api.language = 1;
        expect((await api.detail(1)).title, '文學少女');
        report['traditional_chinese'] = true;
        await backend.persistSession('validation-session');
        final reopened = WindowsBackend(dataDirectory: dir);
        await reopened.init();
        expect(reopened.session, 'validation-session');
        report['encrypted_session_reopen'] = true;
        report['pass'] = true;
        await File(
          'dist/windows-network-verification.json',
        ).writeAsString(const JsonEncoder.withIndent('  ').convert(report));
      }, LiveNetwork());
      WenkuApi.desktop = null;
      // Keep the isolated test cache for inspection; it contains no real account credentials.
    },
    timeout: const Timeout(Duration(minutes: 3)),
  );
}
