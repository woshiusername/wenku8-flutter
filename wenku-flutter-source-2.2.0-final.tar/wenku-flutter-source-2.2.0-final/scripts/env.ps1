$env:JAVA_HOME = 'D:\fluter\.tools\jdk-17.0.20.1+1'
$env:ANDROID_HOME = 'D:\fluter\.tools\android-sdk'
$env:GRADLE_USER_HOME = 'D:\fluter\.tools\gradle-cache'
$env:PUB_CACHE = 'D:\fluter\.tools\pub-cache'
$env:CI = 'true'
$env:PATH = "$env:JAVA_HOME\bin;D:\fluter\.tools\flutter\bin;$env:PATH"
