"""Extract compiler archives and read SDK MSI tables without executing installers."""
import ctypes, json, shutil, subprocess, zipfile
from ctypes import wintypes as W
from pathlib import Path
from urllib.parse import unquote

root = Path(r'D:\wenku8_flutter_build_20261007\.tools').resolve()
cache = root / 'msvc-cache'
destination = root / 'msvc'
destination.mkdir(exist_ok=True)
msi = ctypes.WinDLL('msi.dll')
msi.MsiOpenDatabaseW.argtypes = [W.LPCWSTR, W.LPCWSTR, ctypes.POINTER(W.UINT)]
msi.MsiDatabaseOpenViewW.argtypes = [W.UINT, W.LPCWSTR, ctypes.POINTER(W.UINT)]
msi.MsiViewExecute.argtypes = [W.UINT, W.UINT]
msi.MsiViewFetch.argtypes = [W.UINT, ctypes.POINTER(W.UINT)]
msi.MsiRecordGetStringW.argtypes = [W.UINT, W.UINT, W.LPWSTR, ctypes.POINTER(W.DWORD)]
msi.MsiRecordReadStream.argtypes = [W.UINT, W.UINT, ctypes.c_void_p, ctypes.POINTER(W.DWORD)]
msi.MsiCloseHandle.argtypes = [W.UINT]

def safe(path):
    resolved = path.resolve()
    if not resolved.is_relative_to(root): raise RuntimeError('Extraction path outside the build tools directory')
    return resolved

def rows(db, sql, columns):
    view = W.UINT()
    error = msi.MsiDatabaseOpenViewW(db, sql, ctypes.byref(view))
    if error: raise RuntimeError(f'MSI query error {error}: {sql}')
    try:
        if msi.MsiViewExecute(view, 0): raise RuntimeError('MSI read failed')
        while True:
            record = W.UINT()
            status = msi.MsiViewFetch(view, ctypes.byref(record))
            if status == 259: break
            if status: raise RuntimeError(f'MSI record error {status}')
            try:
                values = []
                for index in range(1, columns + 1):
                    length = W.DWORD(0)
                    msi.MsiRecordGetStringW(record, index, None, ctypes.byref(length))
                    buffer = ctypes.create_unicode_buffer(length.value + 1)
                    length.value += 1
                    if msi.MsiRecordGetStringW(record, index, buffer, ctypes.byref(length)): raise RuntimeError('MSI string error')
                    values.append(buffer.value)
                yield values
            finally: msi.MsiCloseHandle(record)
    finally: msi.MsiCloseHandle(view)

def unpack_sdk(path):
    db = W.UINT()
    if msi.MsiOpenDatabaseW(str(path), None, ctypes.byref(db)): raise RuntimeError('Cannot read SDK MSI')
    try:
        directories = {key:(parent,name) for key,parent,name in rows(db, 'SELECT `Directory`,`Directory_Parent`,`DefaultDir` FROM `Directory`', 3)}
        components = {key:directory for key,directory in rows(db, 'SELECT `Component`,`Directory_` FROM `Component`', 2)}
        def folder(key):
            if key not in directories: return Path()
            parent,name = directories[key]
            if not parent: return Path()
            name = name.split(':')[0].split('|')[-1]
            return folder(parent) if name in ['.', 'SourceDir'] else folder(parent) / name
        wanted = {}
        for key,component,name in rows(db, 'SELECT `File`,`Component_`,`FileName` FROM `File`', 3):
            relative = folder(components[component]) / name.split('|')[-1]
            if any(part.lower() == 'source' for part in relative.parts): continue
            wanted[key] = relative
        for (cabinet,) in rows(db, 'SELECT `Cabinet` FROM `Media`', 1):
            if not cabinet: continue
            if cabinet.startswith('#'): raise RuntimeError('Unexpected embedded SDK cabinet')
            cabinet_file = path.parent / cabinet
            extracted = safe(root / 'sdk-cabinets' / cabinet_file.stem)
            extracted.mkdir(parents=True, exist_ok=True)
            if not (extracted / '.complete').exists():
                result = subprocess.run(['expand.exe','-F:*',str(cabinet_file),str(extracted)], capture_output=True)
                if result.returncode: raise RuntimeError('Cabinet extraction failed: ' + cabinet)
                (extracted / '.complete').touch()
            for file in extracted.iterdir():
                if file.name in wanted:
                    target = safe(destination / wanted[file.name])
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(file, target)
        print('SDK extracted:', path.name, len(wanted), flush=True)
    finally: msi.MsiCloseHandle(db)

for path in cache.rglob('*.vsix'):
    if (destination / '.compiler-archives-complete').exists(): break
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            relative = unquote(info.filename).replace('\\','/')
            if not relative.startswith('Contents/') or info.is_dir(): continue
            relative = relative[len('Contents/'):]
            if not relative.startswith('VC/'): continue
            target = safe(destination / relative)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.read(info))
print('Compiler archives extracted', flush=True)

required = [
    'Windows SDK Desktop Headers x86-x86_en-us.msi',
    'Windows SDK Desktop Libs x64-x86_en-us.msi',
    'Windows SDK Desktop Tools x64-x86_en-us.msi',
    'Windows SDK for Windows Store Apps Headers-x86_en-us.msi',
    'Windows SDK for Windows Store Apps Headers OnecoreUap-x86_en-us.msi',
    'Windows SDK for Windows Store Apps Libs-x86_en-us.msi',
    'Windows SDK for Windows Store Apps Tools-x86_en-us.msi',
    'Universal CRT Headers Libraries and Sources-x86_en-us.msi',
]
for name in required:
    matches = list(cache.rglob(name))
    if len(matches) != 1: raise RuntimeError('SDK payload not found: ' + name)
    unpack_sdk(matches[0])
print('Portable compiler:', next(destination.rglob('Hostx64/x64/cl.exe')), flush=True)
