param([switch]$Debug, [switch]$Test)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\env.ps1"
$source = Split-Path -Parent $PSScriptRoot
$appVersion = [regex]::Match((Get-Content -LiteralPath "$source\pubspec.yaml" -Raw), '(?m)^version:\s*([^+\s]+)').Groups[1].Value
if (!$appVersion) { throw 'Application version is missing.' }
$stage = 'D:\wenku8_flutter_build_20261007'
$marker = Join-Path $stage '.wenku-staging'
if ((Test-Path -LiteralPath $stage) -and !(Test-Path -LiteralPath $marker)) {
    throw 'The staging path is not marked for this project. Inspect it before building.'
}
New-Item -ItemType Directory -Path $stage -Force | Out-Null
Set-Content -LiteralPath $marker -Value $source -Encoding utf8
robocopy $source $stage /E /XD build .dart_tool .gradle screenshots dist /XF local.properties *.iml /NFL /NDL /NJH /NJS /NP
if ($LASTEXITCODE -ge 8) { throw 'Source synchronization failed.' }
$proxy = $null
try {
    if (!(Get-NetTCPConnection -State Listen -LocalPort 18766 -ErrorAction SilentlyContinue)) {
        $proxy = Start-Process -FilePath (Get-Command python).Source -ArgumentList 'D:\fluter\scripts\maven_proxy.py' -WindowStyle Hidden -PassThru
        Start-Sleep -Seconds 1
    }
    Push-Location -LiteralPath $stage
    try {
        if (!$Debug) {
            $pubspec = Get-Content -LiteralPath 'pubspec.yaml' -Raw
            $pubspec = $pubspec -replace '(?m)^  integration_test:\r?\n    sdk: flutter\r?\n', ''
            Set-Content -LiteralPath 'pubspec.yaml' -Value $pubspec -Encoding utf8
        }
        flutter pub get --offline
        if ($LASTEXITCODE -ne 0) { throw 'Dependency resolution failed.' }
        if ($Test) {
            flutter test test
            if ($LASTEXITCODE -ne 0) { throw 'Tests failed.' }
        }
        $mode = if ($Debug) { '--debug' } else { '--release' }
        flutter build apk $mode --no-pub --split-per-abi
        if ($LASTEXITCODE -ne 0) { throw 'APK build failed.' }
        $dist = Join-Path $source 'dist'
        New-Item -ItemType Directory -Path $dist -Force | Out-Null
        $variant = if ($Debug) { 'debug' } else { 'release' }
        $debugSuffix = if ($Debug) { '-debug' } else { '' }
        $architectures = @{ 'arm64-v8a' = 'arm64'; 'armeabi-v7a' = 'arm32'; 'x86_64' = 'x86_64' }
        foreach ($abi in $architectures.Keys) {
            $built = "$stage\build\app\outputs\flutter-apk\app-$abi-$variant.apk"
            Copy-Item -LiteralPath $built -Destination "$dist\wenku-flutter-$appVersion-$($architectures[$abi])$debugSuffix.apk" -Force
        }
    } finally { Pop-Location }
} finally {
    if ($proxy -and !$proxy.HasExited) { Stop-Process -Id $proxy.Id }
}
