"""Read and exercise only this app's visible Android UI during local validation."""
import json, re, subprocess, sys
from pathlib import Path
import xml.etree.ElementTree as ET

package = 'dev.wenku.light_novel_reader'
folder = Path(__file__).resolve().parents[1] / 'screenshots'
folder.mkdir(exist_ok=True)
def adb(*args):
    return subprocess.check_output(['adb', *args], encoding='utf-8', errors='replace')
def foreground():
    state = adb('shell', 'dumpsys', 'activity', 'activities')
    active = [line for line in state.splitlines() if 'topResumedActivity=' in line]
    if not any(package in line for line in active):
        raise RuntimeError('The reader app must be in the foreground.')
def snapshot():
    foreground()
    output = adb('shell', 'uiautomator', 'dump', '/sdcard/wenku-validation-ui.xml')
    if 'dumped to:' not in output:
        raise RuntimeError('The UI did not become idle; refusing to use a stale snapshot.')
    adb('pull', '/sdcard/wenku-validation-ui.xml', str(folder / 'validation-ui.xml'))
    return ET.parse(folder / 'validation-ui.xml').getroot()
def label(node):
    return node.attrib.get('content-desc') or node.attrib.get('text') or node.attrib.get('hint') or ''
def bounds(node):
    return list(map(int, re.findall(r'\d+', node.attrib['bounds'])))

mode = sys.argv[1]
root = snapshot() if mode != 'screenshot' else None
if mode == 'snapshot':
    print(json.dumps([{'label':label(n), 'class':n.attrib.get('class'), 'bounds':bounds(n)} for n in root.iter('node') if n.attrib.get('clickable') == 'true' and len(label(n)) < 130], ensure_ascii=True))
elif mode == 'click':
    needle = sys.argv[2]
    candidates = [n for n in root.iter('node') if n.attrib.get('clickable') == 'true' and needle in label(n)]
    if not candidates: raise RuntimeError('No visible clickable match: ' + needle)
    node = candidates[0]
    x1,y1,x2,y2 = bounds(node)
    adb('shell','input','tap',str((x1+x2)//2),str((y1+y2)//2))
    print(json.dumps({'clicked':label(node), 'bounds':[x1,y1,x2,y2]}, ensure_ascii=True))
elif mode == 'input':
    field = next(n for n in root.iter('node') if n.attrib.get('class') == 'android.widget.EditText')
    x1,y1,x2,y2 = bounds(field)
    adb('shell','input','tap',str((x1+x2)//2),str((y1+y2)//2))
    value = sys.argv[2]
    if not value.isascii(): raise RuntimeError('Use an ASCII search term for adb input.')
    adb('shell','input','text',value)
    adb('shell','input','keyevent','66')
elif mode == 'screenshot':
    foreground()
    name = sys.argv[2]
    if not re.fullmatch(r'[a-z0-9_-]+', name): raise RuntimeError('Invalid screenshot name')
    adb('shell','screencap','-p','/sdcard/wenku-validation.png')
    adb('pull','/sdcard/wenku-validation.png', str(folder / f'{name}.png'))
elif mode == 'scroll':
    nodes = [n for n in root.iter('node') if n.attrib.get('scrollable') == 'true']
    if not nodes: raise RuntimeError('No visible scrollable area')
    x1,y1,x2,y2 = bounds(nodes[-1])
    direction = sys.argv[2]
    if direction == 'left': start,end = (x1+(x2-x1)*.8,(y1+y2)/2),(x1+(x2-x1)*.2,(y1+y2)/2)
    elif direction == 'right': start,end = (x1+(x2-x1)*.2,(y1+y2)/2),(x1+(x2-x1)*.8,(y1+y2)/2)
    elif direction == 'up': start,end = ((x1+x2)/2,y1+(y2-y1)*.8),((x1+x2)/2,y1+(y2-y1)*.2)
    else: raise RuntimeError('Unsupported direction')
    adb('shell','input','swipe',*(str(round(v)) for v in (*start,*end)), '350')
elif mode == 'click_image':
    nodes = [n for n in root.iter('node') if n.attrib.get('class') == 'android.widget.ImageView' and n.attrib.get('clickable') == 'true']
    if not nodes: raise RuntimeError('No visible clickable illustration')
    x1,y1,x2,y2 = bounds(nodes[0])
    adb('shell','input','tap',str((x1+x2)//2),str((y1+y2)//2))
elif mode == 'doubletap':
    node = next(root.iter('node'))
    x1,y1,x2,y2 = bounds(node)
    x,y = (x1+x2)//2,(y1+y2)//2
    adb('shell', f'input tap {x} {y}; input tap {x} {y}')
