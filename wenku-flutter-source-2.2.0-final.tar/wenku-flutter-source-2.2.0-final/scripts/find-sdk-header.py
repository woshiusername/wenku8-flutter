from pathlib import Path
import ctypes
context = {}
exec(Path(__file__).with_name('extract-toolchain.py').read_text().split("for path in cache.rglob('*.vsix'):")[0], context)
msi, W, rows = context['msi'], context['W'], context['rows']
for path in context['cache'].rglob('*Headers*.msi'):
    db = W.UINT()
    if msi.MsiOpenDatabaseW(str(path), None, ctypes.byref(db)): continue
    try:
        matches = [name for _,name in rows(db, 'SELECT `File`,`FileName` FROM `File`', 2) if 'dxgi.h' in name.lower()]
        if matches: print(path.name, matches)
    finally: msi.MsiCloseHandle(db)
