# 文库 · Flutter 重构版

安卓 2.2.0 已交付：支持列表/封面网格切换、上下滚动/左右翻页/竖排右起阅读，应用名为“文库”。安装包和验证记录见 `dist/2.2.0-安卓更新说明.md`。

Windows 版 2.1.0 已交付：`dist/windows/文库/文库.exe`。将整个目录保留在一起运行，也可使用 `dist/文库-Windows-2.1.0-x64.zip`。Windows 验证结果见 `dist/windows-验证报告.md`。

Windows 版独立计算原客户端的时间校验并连接服务器，支持鼠标与键盘阅读，用户数据保存在 `%LOCALAPPDATA%\Wenku`。Windows 端用 DPAPI 加密登录会话。构建脚本为 `scripts/build-windows.ps1`，编译使用项目英文路径内的便携 MSVC / Windows SDK 与 Ninja。

安卓已交付版本为 2.0.1，见 `dist/2.0.1更新说明.md`；本次没有继续平板适配或覆盖平板安装包。

Flutter 3.35.7 / Dart 3.9.2，Android 应用 id：`dev.wenku.light_novel_reader`，可与原版并存。

界面采用暖白、墨色和朱红，书库以真实封面与简洁书籍排版为主。支持手机底部导航、平板侧栏、深色外观与四种阅读纸张颜色。

已实现：

- 书库四种分类、全部十三种排序、翻页、刷新。
- 按书名或作者搜索、搜索历史、小说详情、分卷目录、正文与插图。
- 本地收藏、阅读进度持久化、章节切换、字体与行距、屏幕常亮。
- 在“阅读设置”或“我的”切换上下滚动／左右翻页，自动保存选择；横向阅读按屏幕和字号分页，插图独占一页。
- 插图标记不会显示为正文；点开插图后可全屏缩放、拖动、双击放大，并恢复大小。
- 全书或分卷缓存；正文、目录、阅读过的封面与插图保存在应用内部存储。
- Wenku8 用户名／邮箱登录、会话持久化、退出登录、账号信息、签到。
- 云端书架查看、导入本地、加入与移除。
- 书评与回复浏览、分页，以及用户主动发表书评／回复。
- 简体／繁体内容、缓存管理和实际服务器连接检查。

联网使用原版 HTTPS 中继 `https://wenku8-relay.mewx.org/`。保留原 APK 的 `libcpp.so` 和 JNI 入口，每次请求动态生成原生版本校验值；Android `HttpURLConnection` 处理 gzip 和 PHPSESSID。没有保存登录密码。不能用一次抓取的校验值替代原生函数，因为它会随时间变化。

## 构建

执行 `scripts/build.ps1`，使用 `D:\fluter\.tools` 下现有 Flutter、JDK、SDK、NDK 和缓存。Windows 下 Flutter 的 shader 编译器不支持此中文输出路径，因此脚本同步源码到 `D:\wenku8_flutter_build_20261007` 再构建，最后将 APK 复制到本项目 `dist`。

如使用其他电脑，调整 `scripts/env.ps1` 的工具路径。Gradle 缓存中的仓库配置会使用现有 `D:\fluter\scripts\maven_proxy.py`；构建脚本会在需要时启动该本地工具。

## 验证

`flutter analyze --no-pub`；`flutter test test`。

`integration_test/app_test.dart` 在安卓真机上调用相同的原生联网层，验证书库、翻页、排行、搜索、详情、目录、正文、封面、书评、繁体中文、离线缓存，以及收藏与章节切换。集成测试应从英文构建路径运行。

当前执行结果与限制见 `dist/验证报告.md`。Release 构建脚本会从英文路径的临时 pubspec 中移除仅用于测试的原生插件，源码工程仍保留测试依赖。

联网只读核验结果在 `../reverse/verified/report.json`。真实账号的登录成功、云书架写入、签到和评论发表需要使用者登录后验收；自动测试不会向论坛发表内容。

## 反编译与来源

原包资源和 Smali：`../reverse/decoded`。JADX 输出：`../reverse/jadx`。JADX 报告 38 处混淆方法反编译错误，保留对应 Smali 作为依据；Java 输出不是可以直接重新编译的原始工程。

原项目：[MewX/light-novel-library_Wenku8_Android](https://github.com/MewX/light-novel-library_Wenku8_Android)。继承其 GPL-2.0 许可，见 LICENSE。保留的原生库来源于用户提供的 1.30 安装包；其完整 C++ 源码不在安装包内。

小说和插图由用户主动访问 Wenku8 获得；本项目未预装小说正文。测试夹具仅保存用于 XML 解析验证的书目和目录响应。
