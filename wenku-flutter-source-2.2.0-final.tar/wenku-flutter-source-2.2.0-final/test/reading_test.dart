import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:light_novel_reader/api.dart';
import 'package:light_novel_reader/illustration.dart';
import 'package:light_novel_reader/models.dart';
import 'package:light_novel_reader/reader.dart';
import 'package:light_novel_reader/reading_content.dart';
import 'package:light_novel_reader/store.dart';

class ReadingApi extends WenkuApi {
  @override
  Future<String> text(int id, int cid, {bool refresh = false}) async =>
      List.filled(
        50,
        '这个故事从一页书开始，文字应该完整保留。🙂👨‍👩‍👧‍👦\n继续阅读新的段落。',
      ).join('\n');
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test(
    'Actual Wenku illustration markers produce fourteen images and no label text',
    () {
      final source = File('test/fixtures/illustrations.txt').readAsStringSync();
      final blocks = parseReadingContent(source);
      expect(blocks.where((b) => b.imageUrl != null).length, 14);
      expect(
        blocks.where((b) => b.text != null).map((b) => b.text).join(),
        isNot(contains('<!--image-->')),
      );
      expect(
        blocks.every((b) => b.text == null || b.text!.trim().isNotEmpty),
        true,
      );
    },
  );
  test(
    'Image markup is removed while adjacent text, URL queries and the word image survive',
    () {
      final blocks = parseReadingContent(
        '前文 image 不应删除。\n<!--IMAGE-->http://example.com/a.JPG?v=2<!--image-->\n[img]https://example.com/b.png[/img]\n<img src="https://example.com/c.webp">\n后文',
      );
      expect(blocks.map((b) => b.imageUrl).whereType<String>().toList(), [
        'https://example.com/a.JPG?v=2',
        'https://example.com/b.png',
        'https://example.com/c.webp',
      ]);
      expect(blocks.where((b) => b.text != null).map((b) => b.text).toList(), [
        '前文 image 不应删除。',
        '后文',
      ]);
    },
  );
  test(
    'Horizontal pages retain every grapheme and fit the available text area',
    () {
      const style = TextStyle(fontSize: 24, height: 2.1, letterSpacing: .35);
      final source = List.filled(
        30,
        '这是分页验证。🙂👨‍👩‍👧‍👦保留汉字、标点和表情。',
      ).join('\n');
      final blocks = parseReadingContent(source);
      final pages = paginateReadingContent(
        blocks: blocks,
        width: 264,
        height: 390,
        headerHeight: 110,
        style: style,
        textScaler: const TextScaler.linear(1.3),
        direction: TextDirection.ltr,
      );
      expect(pages.length, greaterThan(2));
      final actual = pages
          .expand((p) => p.parts)
          .map((p) => p.text ?? '')
          .join();
      expect(actual, blocks.map((b) => b.text).join());
      final graphemes = source.characters.where((c) => c != '\n').toList();
      expect(actual.characters.toList(), graphemes);
      expect(pages.where((p) => p.showHeader).length, 1);
      for (final page in pages) {
        var height = page.showHeader ? 110.0 : 0.0;
        for (final part in page.parts) {
          final painter = TextPainter(
            text: TextSpan(text: part.text, style: style),
            textScaler: const TextScaler.linear(1.3),
            textDirection: TextDirection.ltr,
          )..layout(maxWidth: 264);
          height +=
              painter.height +
              (part.paragraphEnd && part != page.parts.last ? 13 : 0);
          painter.dispose();
        }
        expect(height, lessThanOrEqualTo(390.1));
      }
    },
  );
  test('Each illustration has its own horizontal page in source order', () {
    final blocks = parseReadingContent(
      '前文\n<!--image-->https://example.com/a.jpg<!--image-->后文\n<!--image-->https://example.com/b.jpg<!--image-->',
    );
    final pages = paginateReadingContent(
      blocks: blocks,
      width: 330,
      height: 600,
      headerHeight: 100,
      style: const TextStyle(fontSize: 20, height: 1.85),
      textScaler: TextScaler.noScaling,
      direction: TextDirection.ltr,
    );
    expect(pages.map((p) => p.parts.length).toList(), [1, 1, 1, 1]);
    expect(
      pages.expand((p) => p.parts).map((p) => p.text ?? p.imageUrl).toList(),
      ['前文', 'https://example.com/a.jpg', '后文', 'https://example.com/b.jpg'],
    );
  });

  testWidgets('Reader mode switches, swipes and repaginates without overflow', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(WenkuApi.channel, (_) async => null);
    addTearDown(
      () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(WenkuApi.channel, null),
    );
    final store = ReaderStore(ReadingApi());
    await tester.pumpWidget(
      MaterialApp(
        home: ReaderScreen(store, const Novel(id: 55, title: '阅读验证'), const [
          Chapter(66, '第一章', '第一卷'),
          Chapter(67, '第二章', '第一卷'),
        ], 0),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.byType(PageView), findsNothing);
    await tester.drag(find.byType(ListView), const Offset(0, -600));
    await tester.pumpAndSettle(const Duration(seconds: 1));
    final fraction = store.record(55)!['fraction'] as double;
    expect(fraction, greaterThan(0));
    await tester.tap(find.byTooltip('阅读设置'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('reading_mode_picker')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('左右翻页').last);
    await tester.pumpAndSettle();
    expect(store.horizontalReading, true);
    expect(find.byType(PageView), findsOneWidget);
    expect(tester.takeException(), isNull);
    Navigator.of(tester.element(find.byType(ReaderScreen))).pop();
    await tester.pumpAndSettle();
    final before = find.byType(PageView).evaluate().single.widget as PageView;
    final beforePage = before.controller!.page!;
    await tester.drag(find.byType(PageView), const Offset(-300, 0));
    await tester.pumpAndSettle();
    final after = tester.widget<PageView>(find.byType(PageView));
    expect(after.controller!.page, greaterThan(beforePage));
    final swipedPage = after.controller!.page!;
    await tester.sendKeyEvent(LogicalKeyboardKey.arrowRight);
    await tester.pumpAndSettle();
    expect(
      tester.widget<PageView>(find.byType(PageView)).controller!.page,
      greaterThan(swipedPage),
    );
    await tester.tap(find.byTooltip('阅读设置'));
    await tester.pumpAndSettle();
    await tester.drag(find.byType(Slider).first, const Offset(65, 0));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await tester.tap(find.byKey(const ValueKey('reading_mode_picker')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('上下滚动').last);
    await tester.pumpAndSettle();
    expect(store.horizontalReading, false);
    expect(find.byType(PageView), findsNothing);
    Navigator.of(tester.element(find.byType(ReaderScreen))).pop();
    await tester.pumpAndSettle();
    expect(store.record(55)!['fraction'] as double, greaterThan(0));
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
  });

  testWidgets(
    'Small images zoom and pan over the complete screen, including letterboxing',
    (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final dir = Directory.systemTemp.createTempSync('wenku-viewer-');
      final file = File('${dir.path}/tiny.png')
        ..writeAsBytesSync(
          base64Decode(
            'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=',
          ),
        );
      addTearDown(() {
        file.deleteSync();
        dir.deleteSync();
      });
      await tester.pumpWidget(MaterialApp(home: IllustrationViewer(file)));
      await tester.pumpAndSettle();
      final viewer = find.byKey(const ValueKey('illustration_viewport'));
      expect(tester.getSize(viewer), const Size(390, 844));
      final left = await tester.createGesture(pointer: 1),
          right = await tester.createGesture(pointer: 2);
      await left.down(const Offset(140, 110));
      await right.down(const Offset(250, 110));
      await left.moveTo(const Offset(130, 110));
      await right.moveTo(const Offset(260, 110));
      await tester.pump();
      await left.moveTo(const Offset(70, 100));
      await right.moveTo(const Offset(320, 120));
      await tester.pump();
      await left.up();
      await right.up();
      await tester.pumpAndSettle();
      final transform = tester
          .widget<InteractiveViewer>(viewer)
          .transformationController!;
      expect(transform.value.getMaxScaleOnAxis(), greaterThan(1.2));
      final before = transform.value.getTranslation().x;
      await tester.dragFrom(const Offset(80, 200), const Offset(90, 10));
      await tester.pumpAndSettle();
      expect(transform.value.getTranslation().x, isNot(before));
      await tester.tap(find.byTooltip('恢复大小'));
      await tester.pumpAndSettle();
      expect(transform.value.getMaxScaleOnAxis(), closeTo(1, .01));
      await tester.tapAt(const Offset(220, 500));
      await tester.pump(const Duration(milliseconds: 80));
      await tester.tapAt(const Offset(220, 500));
      await tester.pumpAndSettle();
      expect(transform.value.getMaxScaleOnAxis(), closeTo(3, .01));
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
    },
  );

  test('Reading mode and progress survive saving and reopening', () async {
    final dir = await Directory.systemTemp.createTemp('wenku-mode-');
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          WenkuApi.channel,
          (call) async => call.method == 'storagePath' ? dir.path : null,
        );
    try {
      final store = ReaderStore(WenkuApi());
      await store.init();
      store.horizontalReading = true;
      await store.remember(
        const Novel(id: 55, title: '验证'),
        const Chapter(66, '第一章', '第一卷'),
        0,
        fraction: .4,
        horizontal: true,
      );
      final reopened = ReaderStore(WenkuApi());
      await reopened.init();
      expect(reopened.horizontalReading, true);
      expect(reopened.record(55)!['fraction'], .4);
    } finally {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(WenkuApi.channel, null);
      WenkuApi.sharedCache = null;
      File('${dir.path}/reader_state.json').deleteSync();
      Directory('${dir.path}/cache_v2').deleteSync();
      dir.deleteSync();
    }
  });
}
