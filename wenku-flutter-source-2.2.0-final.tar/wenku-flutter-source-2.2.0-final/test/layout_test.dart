import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:light_novel_reader/api.dart';
import 'package:light_novel_reader/main.dart';
import 'package:light_novel_reader/models.dart';
import 'package:light_novel_reader/store.dart';

class FixtureApi extends WenkuApi {
  @override
  Future<BookPage> list(String sort, int page) async =>
      BookPage.parse(File('test/fixtures/lastupdate.xml').readAsStringSync());
}

void main() {
  for (final size in [
    const Size(320, 640),
    const Size(390, 844),
    const Size(834, 1112),
    const Size(1366, 768),
  ]) {
    testWidgets('Real book titles fit ${size.width} x ${size.height}', (
      tester,
    ) async {
      tester.view.physicalSize = size;
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final store = ReaderStore(FixtureApi());
      await tester.pumpWidget(WenkuApp(store));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      expect(find.text('书库'), findsWidgets);
      await tester.tap(find.text('我的').last);
      await tester.pumpAndSettle();
      expect(find.text('还没有登录'), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.tap(find.text('书架').last);
      await tester.pumpAndSettle();
      expect(find.text('书架为空'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
  }
}
