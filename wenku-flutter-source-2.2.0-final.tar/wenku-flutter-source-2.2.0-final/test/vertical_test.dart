import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:light_novel_reader/api.dart';
import 'package:light_novel_reader/main.dart';
import 'package:light_novel_reader/models.dart';
import 'package:light_novel_reader/reader.dart';
import 'package:light_novel_reader/reading_content.dart';
import 'package:light_novel_reader/store.dart';
import 'package:light_novel_reader/vertical_reader.dart';
import 'package:light_novel_reader/widgets.dart';

class BookFixtureApi extends WenkuApi {
  @override
  Future<BookPage> list(String sort, int page) async => BookPage([
    const Novel(
      id: 19,
      title: '列表书目',
      author: '作者',
      status: '连载中',
      intro: '故事简介',
    ),
  ], 1);
  @override
  Future<String> text(int id, int cid, {bool refresh = false}) async =>
      List.filled(
        50,
        '「新的竖排故事。」文字从上到下，每一列从右到左。Flutter 12 SAO。🙂👨‍👩‍👧‍👦',
      ).join('\n');
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test(
    'Vertical columns read downward and then leftward without losing text',
    () {
      final blocks = parseReadingContent(
        '甲乙丙丁戊己庚辛壬癸\n「中文。」Flutter 12 SAO。🙂👨‍👩‍👧‍👦',
      );
      final pages = paginateVertical(
        blocks: blocks,
        size: const Size(220, 130),
        style: const TextStyle(fontSize: 20),
        scaler: TextScaler.noScaling,
        lineHeight: 1.8,
      );
      final placements = pages.expand((p) => p.placements).toList();
      expect(
        placements.map((p) => p.run.source).join(),
        blocks.map((b) => b.text).join(),
      );
      expect(placements[1].position.dy, greaterThan(placements[0].position.dy));
      final firstColumn = placements.first.position.dx;
      final nextColumn = placements.firstWhere(
        (p) => p.position.dx < firstColumn,
      );
      expect(nextColumn.position.dy, 0);
      expect(placements.any((p) => p.run.display == '﹁'), true);
      expect(placements.any((p) => p.run.display == '︒'), true);
      expect(
        verticalRuns('Flutter').single.orientation,
        VerticalOrientation.sideways,
      );
      expect(
        placements.firstWhere((p) => p.run.source == '12').run.orientation,
        VerticalOrientation.compact,
      );
      expect(placements.any((p) => p.run.source == '👨‍👩‍👧‍👦'), true);
      for (final placement in placements) {
        expect(
          placement.position.dy + placement.extent,
          lessThanOrEqualTo(130.01),
        );
        expect(placement.position.dx, inInclusiveRange(0, 220));
      }
    },
  );
  test(
    'Long Latin runs split to fit columns and illustrations keep source order',
    () {
      final word = 'longword' * 80;
      final blocks = parseReadingContent(
        '$word\n<!--image-->https://example.com/a.jpg<!--image-->后文',
      );
      final pages = paginateVertical(
        blocks: blocks,
        size: const Size(240, 160),
        style: const TextStyle(fontSize: 20),
        scaler: TextScaler.noScaling,
        lineHeight: 1.8,
      );
      expect(
        pages.expand((p) => p.placements).map((p) => p.run.source).join(),
        '$word后文',
      );
      expect(
        pages.where((p) => p.imageUrl != null).single.imageUrl,
        'https://example.com/a.jpg',
      );
      expect(pages.last.placements.map((p) => p.run.source).join(), '后文');
      expect(
        pages.expand((p) => p.placements).every((p) => p.extent <= 160.01),
        true,
      );
    },
  );

  testWidgets(
    'Book list is default, grid remains selectable, and decorative copy is gone',
    (tester) async {
      final store = ReaderStore(BookFixtureApi());
      await tester.pumpWidget(WenkuApp(store));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('book_list')), findsOneWidget);
      expect(find.byType(BookGrid), findsNothing);
      expect(find.text('翻开一本书，故事就开始了。'), findsNothing);
      await tester.tap(find.byKey(const ValueKey('book_view_toggle')).first);
      await tester.pumpAndSettle();
      expect(store.bookList, false);
      expect(find.byType(BookGrid), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );

  for (final size in [const Size(390, 844), const Size(1163, 776)]) {
    testWidgets(
      'Vertical reader paints and turns right-to-left at ${size.width}',
      (tester) async {
        tester.view.physicalSize = size;
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(WenkuApi.channel, (_) async => null);
        addTearDown(
          () => TestDefaultBinaryMessengerBinding
              .instance
              .defaultBinaryMessenger
              .setMockMethodCallHandler(WenkuApi.channel, null),
        );
        final store = ReaderStore(BookFixtureApi())
          ..readingMode = ReadingMode.vertical;
        await tester.pumpWidget(
          MaterialApp(
            home: ReaderScreen(
              store,
              const Novel(id: 19, title: '竖排验证'),
              const [Chapter(1, '章节', '第一卷')],
              0,
            ),
          ),
        );
        await tester.pumpAndSettle();
        expect(find.byType(VerticalChapter), findsOneWidget);
        final page = tester.widget<PageView>(find.byType(PageView));
        expect(page.reverse, true);
        await tester.drag(
          find.byType(PageView),
          Offset(tester.getSize(find.byType(PageView)).width * .8, 0),
        );
        await tester.pumpAndSettle(const Duration(seconds: 1));
        expect(
          tester.widget<PageView>(find.byType(PageView)).controller!.page,
          greaterThan(0),
        );
        expect(store.record(19)?['readingMode'], 'vertical');
        expect(tester.takeException(), isNull);
        await tester.pumpWidget(const SizedBox());
      },
    );
  }

  test(
    'Vertical preference and book list survive reopening old and new state',
    () async {
      final dir = await Directory.systemTemp.createTemp('wenku-preferences-');
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            WenkuApi.channel,
            (call) async => call.method == 'storagePath' ? dir.path : null,
          );
      try {
        final store = ReaderStore(WenkuApi());
        await store.init();
        store.readingMode = ReadingMode.vertical;
        store.bookList = true;
        await store.save();
        final reopened = ReaderStore(WenkuApi());
        await reopened.init();
        expect(reopened.readingMode, ReadingMode.vertical);
        expect(reopened.bookList, true);
        await File(
          '${dir.path}/reader_state.json',
        ).writeAsString('{"horizontalReading":true}');
        final legacy = ReaderStore(WenkuApi());
        await legacy.init();
        expect(legacy.readingMode, ReadingMode.horizontal);
        expect(legacy.bookList, true);
      } finally {
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(WenkuApi.channel, null);
        WenkuApi.sharedCache = null;
        File('${dir.path}/reader_state.json').deleteSync();
        Directory('${dir.path}/cache_v2').deleteSync();
        dir.deleteSync();
      }
    },
  );
}
