import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:light_novel_reader/models.dart';

String fixture(String name) =>
    File('test/fixtures/$name.xml').readAsStringSync();
void main() {
  test('Actual API catalog retains volume and chapter boundaries', () {
    final chapters = parseCatalog(fixture('catalog'));
    expect(chapters.first.id, 2);
    expect(chapters.first.volume, '第一卷 渴望死亡的小丑');
    expect(chapters.length, greaterThan(100));
    expect(chapters.map((e) => e.id).toSet().length, chapters.length);
    expect(chapters.map((e) => e.volume).toSet().length, greaterThan(10));
  });
  test('Actual list response parses CDATA, attributes and page total', () {
    final page = BookPage.parse(fixture('lastupdate'));
    expect(page.books.length, 10);
    expect(page.pages, greaterThan(100));
    expect(page.books.first.title, isNot(contains('\uFFFD')));
    for (final book in page.books) {
      expect(Novel.fromJson(book.toJson()).title, book.title);
    }
  });
  test('Actual review response retains author, timestamp and thread id', () {
    final reviews = Review.parse(fixture('reviews'));
    expect(reviews, isNotEmpty);
    expect(reviews.first.id, greaterThan(0));
    expect(reviews.first.user, isNotEmpty);
    expect(reviews.first.displayDate.length, 10);
  });
}
