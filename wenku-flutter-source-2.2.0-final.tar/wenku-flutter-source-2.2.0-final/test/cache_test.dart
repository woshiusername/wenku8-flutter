import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:light_novel_reader/api.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('A chapter remains readable after the transport goes offline', () async {
    final dir = await Directory.systemTemp.createTemp('wenku-cache-');
    var offline = false;
    var calls = 0;
    const sample = '用于验证离线读取的章节内容。\n正文读取与联网状态互不依赖。';
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(WenkuApi.channel, (call) async {
          if (call.method == 'storagePath') return dir.path;
          if (call.method == 'request') {
            calls++;
            if (offline) {
              throw PlatformException(code: 'NETWORK', message: 'offline');
            }
            return {'status': 200, 'text': sample};
          }
          return null;
        });
    addTearDown(() async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(WenkuApi.channel, null);
      await dir.delete(recursive: true);
      WenkuApi.sharedCache = null;
    });
    final api = WenkuApi();
    await api.init();
    expect(await api.text(55, 66), sample);
    expect(await api.isCached(55, 66), true);
    final before = calls;
    offline = true;
    expect(await api.text(55, 66), sample);
    expect(calls, before);
    expect(await api.text(55, 66, refresh: true), sample);
    await expectLater(api.text(55, 67), throwsA(isA<WenkuException>()));
  });
}
