import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:light_novel_reader/windows_backend.dart';

void main() {
  test('Windows token matches the supplied Android JNI result', () {
    final time = DateTime.fromMillisecondsSinceEpoch(
      29855886 * 60000,
      isUtc: true,
    );
    expect(windowsVersionToken(time), '1.30-digital-bento-98bcb4f5');
    expect(
      windowsVersionToken(time.add(const Duration(seconds: 59))),
      windowsVersionToken(time),
    );
    expect(
      windowsVersionToken(time.add(const Duration(minutes: 1))),
      isNot(windowsVersionToken(time)),
    );
  });
  test(
    'Windows session encryption round-trips without exposing plain cookie bytes',
    () {
      final services = WindowsServices();
      final plain = utf8.encode('local-validation-session');
      final encrypted = services.protect(plain);
      expect(encrypted, isNot(plain));
      expect(services.protect(encrypted, decrypt: true), plain);
      expect(
        services.encodeGbk('文库 +'),
        base64Encode(utf8.encode('%CE%C4%BF%E2+%2B')),
      );
    },
    skip: !Platform.isWindows,
  );
}
