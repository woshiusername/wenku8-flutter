import 'dart:convert';
import 'dart:io';
import 'api.dart';

/// Opt-in runtime check for the compiled desktop app. It performs only reads.
Future<void> validateDesktop(String output) async {
  final result = <String, dynamic>{};
  try {
    final api = WenkuApi();
    await api.init();
    final meta = await api.detail(1);
    if (meta.title != '文学少女') throw StateError('Metadata encoding mismatch');
    result['metadata'] = true;
    final books = await api.list('lastupdate', 1);
    result['updates'] = books.books.length;
    final page2 = await api.list('lastupdate', 2);
    if (page2.books.first.id == books.books.first.id) {
      throw StateError('Pagination mismatch');
    }
    result['pagination'] = true;
    result['ranking'] = (await api.list('allvisit', 1)).books.length;
    if (!(await api.search(
      'SAO',
      'articlename',
    )).books.any((b) => b.id == 471)) {
      throw StateError('Search mismatch');
    }
    result['search'] = true;
    final catalog = await api.catalog(1, refresh: true);
    result['catalog_chapters'] = catalog.length;
    result['text_characters'] = (await api.text(
      1,
      catalog.first.id,
      refresh: true,
    )).length;
    result['cover_bytes'] = await (await api.image(meta.cover)).length();
    result['reviews'] = (await api.reviews(1, 1)).length;
    result['pass'] =
        books.books.isNotEmpty &&
        catalog.isNotEmpty &&
        (result['text_characters'] as int) > 500;
  } catch (e) {
    result['pass'] = false;
    result['error'] = e.toString();
  }
  result['time'] = DateTime.now().toUtc().toIso8601String();
  await File(output).writeAsString(
    const JsonEncoder.withIndent('  ').convert(result),
    flush: true,
  );
}
