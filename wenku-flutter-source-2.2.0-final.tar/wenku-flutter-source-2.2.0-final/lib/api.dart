import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:xml/xml.dart';
import 'models.dart';
import 'windows_backend.dart';

class WenkuException implements Exception {
  final String message;
  const WenkuException(this.message);
  @override
  String toString() => message;
}

class WenkuApi {
  static const channel = MethodChannel('wenku/native');
  static WindowsBackend? desktop;
  static Future<T?> invokePlatform<T>(
    String method, [
    Map<String, dynamic>? arguments,
  ]) async {
    final result = desktop == null
        ? await channel.invokeMethod<dynamic>(method, arguments)
        : await desktop!.invoke(method, arguments ?? {});
    return result as T?;
  }

  static const errors = {
    0: '请求未被服务器接受',
    2: '用户名或邮箱不存在',
    3: '密码不正确',
    4: '登录已过期，请重新登录',
    5: '已在云端书架',
    6: '云端书架已满',
    7: '这本书不在云端书架',
    8: '主题不存在',
    9: '今天已经签到，或签到失败',
    10: '推荐失败',
    11: '评论暂时无法发表',
    22: '服务器要求重新加载',
  };
  int language = 0;
  String get lang => '&t=$language';
  Directory? cache;
  static Directory? sharedCache;
  static final Map<String, Future<File>> imageLoads = {};
  Future<void> init() async {
    final path = await invokePlatform<String>('storagePath');
    cache = Directory('$path/cache_v2');
    await cache!.create(recursive: true);
    sharedCache = cache;
  }

  Future<String> request(String action, {bool retry = true}) async {
    final attempts = retry ? 2 : 1;
    for (var attempt = 0; attempt < attempts; attempt++) {
      try {
        final raw = await invokePlatform<dynamic>('request', {
          'action': action,
        });
        final response = raw == null
            ? null
            : Map<String, dynamic>.from(raw as Map);
        final status = response?['status'] as int? ?? 0;
        if (status != 200) {
          if (status == 403) throw const WenkuException('服务器暂时限制了访问，请稍后重试');
          throw WenkuException('服务器连接失败（HTTP $status）');
        }
        final text = (response?['text'] as String? ?? '')
            .replaceFirst('\uFEFF', '')
            .trim();
        if (text.isEmpty) throw const WenkuException('服务器没有返回内容');
        if (text.contains('\uFFFD')) {
          throw const WenkuException('服务器返回了异常文字编码，请重试');
        }
        final code = int.tryParse(text);
        if (code != null && code != 1) {
          throw WenkuException(errors[code] ?? '服务器返回错误 $code');
        }
        return text;
      } on PlatformException catch (e) {
        if (attempt + 1 == attempts) {
          throw WenkuException('连接失败，请检查网络后重试。${e.message ?? ''}');
        }
      } on WenkuException {
        rethrow;
      }
      await Future<void>.delayed(const Duration(milliseconds: 400));
    }
    throw const WenkuException('连接失败');
  }

  Future<BookPage> list(String sort, int page) async => BookPage.parse(
    await request('action=novellist&sort=$sort&page=$page$lang'),
  );
  Future<BookPage> search(String key, String type) async => BookPage.parse(
    await request(
      'action=search&searchtype=$type&searchkey=${Uri.encodeComponent(key)}$lang',
    ),
  );
  Future<Novel> detail(int id) async => Novel.fromXml(
    XmlDocument.parse(
      await request('action=book&do=meta&aid=$id$lang'),
    ).rootElement,
    id: id,
  );
  Future<String> intro(int id) => request('action=book&do=intro&aid=$id$lang');
  Future<List<Chapter>> catalog(int id, {bool refresh = false}) async =>
      parseCatalog(
        await cached(
          'catalog_${language}_$id',
          'action=book&do=list&aid=$id$lang',
          refresh: refresh,
        ),
      );
  Future<String> text(int id, int cid, {bool refresh = false}) => cached(
    'text_${language}_${id}_$cid',
    'action=book&do=text&aid=$id&cid=$cid$lang',
    refresh: refresh,
  );
  Future<String> cached(
    String name,
    String action, {
    bool refresh = false,
  }) async {
    final file = cache == null ? null : File('${cache!.path}/$name.txt');
    if (!refresh && file != null && await file.exists()) {
      return file.readAsString();
    }
    try {
      final response = await request(action);
      if (file != null) await file.writeAsString(response, flush: true);
      return response;
    } catch (_) {
      if (file != null && await file.exists()) return file.readAsString();
      rethrow;
    }
  }

  Future<bool> isCached(int id, int cid) async =>
      cache != null &&
      await File('${cache!.path}/text_${language}_${id}_$cid.txt').exists();
  Future<File> image(String url) {
    final key = '${(cache ?? sharedCache)?.path}|$url';
    final existing = imageLoads[key];
    if (existing != null) return existing;
    final task = fetchImage(url).whenComplete(() {
      imageLoads.remove(key);
    });
    imageLoads[key] = task;
    return task;
  }

  Future<File> fetchImage(String url) async {
    final name = base64UrlEncode(utf8.encode(url));
    final file = File('${(cache ?? sharedCache)!.path}/img_$name');
    if (await file.exists()) return file;
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 15);
    client.userAgent = 'Dalvik/2.1.0';
    try {
      final response = await (await client.getUrl(
        Uri.parse(url),
      )).close().timeout(const Duration(seconds: 25));
      if (response.statusCode != 200) throw const WenkuException('图片加载失败');
      final bytes = await response.fold<List<int>>(
        [],
        (result, b) => result..addAll(b),
      );
      final temporary = File('${file.path}.tmp');
      await temporary.writeAsBytes(bytes);
      await temporary.rename(file.path);
      return file;
    } finally {
      client.close();
    }
  }

  Future<void> login(String name, String password) async {
    await invokePlatform<void>('clearSession');
    final action = name.contains('@') ? 'loginemail' : 'login';
    await request(
      'action=$action&username=${Uri.encodeComponent(name)}&password=${Uri.encodeComponent(password)}',
      retry: false,
    );
  }

  Future<void> logout() async {
    try {
      await request('action=logout', retry: false);
    } finally {
      await invokePlatform<void>('clearSession');
    }
  }

  Future<Map<String, String>> user() async {
    final doc = XmlDocument.parse(await request('action=userinfo'));
    return {
      for (final e in doc.descendants.whereType<XmlElement>())
        if (e.getAttribute('name') != null ||
            (e.name.local == 'item' && e.attributes.isNotEmpty))
          (e.getAttribute('name') ?? e.attributes.first.value):
              e.getAttribute('value') ?? e.innerText,
    };
  }

  Future<List<int>> cloudShelf() async {
    final text = await request('action=bookcase$lang');
    final doc = XmlDocument.parse(text);
    return doc.descendants
        .whereType<XmlElement>()
        .map((e) => int.tryParse(e.getAttribute('aid') ?? ''))
        .whereType<int>()
        .toSet()
        .toList();
  }

  Future<void> cloudAdd(int id) async {
    await request('action=bookcase&do=add&aid=$id', retry: false);
  }

  Future<void> cloudDelete(int id) async {
    await request('action=bookcase&do=del&aid=$id', retry: false);
  }

  Future<void> sign() async {
    await request('action=block&do=sign', retry: false);
  }

  Future<List<Review>> reviews(int id, int page) async => Review.parse(
    await request('action=review&do=list&aid=$id&page=$page$lang'),
  );
  Future<List<Review>> replies(int id, int page) async => Review.parse(
    await request('action=review&do=show&rid=$id&page=$page$lang'),
  );
  Future<void> postReview(int id, String title, String text) async {
    final t = await invokePlatform<String>('encodeGbk', {'text': title});
    final c = await invokePlatform<String>('encodeGbk', {'text': text});
    await request(
      'action=review&do=post&aid=$id&title=$t&content=$c',
      retry: false,
    );
  }

  Future<void> reply(int id, String text) async {
    final c = await invokePlatform<String>('encodeGbk', {'text': text});
    await request('action=review&do=reply&rid=$id&content=$c', retry: false);
  }

  Future<void> clearCache() async {
    if (cache != null) {
      for (final entity in cache!.listSync()) {
        if (entity is File) await entity.delete();
      }
    }
  }

  int get cacheCount => cache?.existsSync() == true
      ? cache!
            .listSync()
            .where(
              (e) =>
                  e.path.split(Platform.pathSeparator).last.startsWith('text_'),
            )
            .length
      : 0;
  Future<void> openUrl(String url) =>
      invokePlatform<void>('openUrl', {'url': url});
}

String prettyCount(int value) =>
    value >= 10000 ? '${(value / 10000).toStringAsFixed(1)}万' : '$value';
String encodeAction(String action) => base64Encode(utf8.encode(action));
