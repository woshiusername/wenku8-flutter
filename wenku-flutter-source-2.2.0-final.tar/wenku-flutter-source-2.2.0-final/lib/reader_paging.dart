import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'api.dart';
import 'models.dart';
import 'illustration.dart';
import 'reading_content.dart';

class PagedChapter extends StatefulWidget {
  final WenkuApi api;
  final Chapter chapter;
  final List<ReadingBlock> blocks;
  final TextStyle style;
  final Color foreground;
  final double initialFraction;
  final bool restoreChrome;
  final void Function(double fraction, int page, int total) onPosition;
  const PagedChapter({
    required this.api,
    required this.chapter,
    required this.blocks,
    required this.style,
    required this.foreground,
    required this.initialFraction,
    required this.onPosition,
    required this.restoreChrome,
    super.key,
  });
  @override
  State<PagedChapter> createState() => _PagedChapterState();
}

class _PagedChapterState extends State<PagedChapter> {
  PageController? controller;
  List<ReadingPage> pages = [];
  Object? layoutKey;
  late double fraction = widget.initialFraction;
  int selected = 0;
  final keyboardFocus = FocusNode(debugLabel: 'Reading pages');
  void turnPage(int direction) {
    if (controller?.hasClients != true) return;
    final page = (selected + direction).clamp(0, pages.length - 1);
    controller!.animateToPage(
      page,
      duration: const Duration(milliseconds: 180),
      curve: Curves.easeOut,
    );
  }

  @override
  void dispose() {
    keyboardFocus.dispose();
    controller?.dispose();
    super.dispose();
  }

  TextStyle get volumeStyle => TextStyle(
    fontSize: 11,
    height: 1.8,
    letterSpacing: 1,
    color: widget.foreground.withValues(alpha: .5),
  );
  TextStyle get titleStyle => TextStyle(
    fontSize: 26,
    height: 1.6,
    fontWeight: FontWeight.w600,
    color: widget.foreground,
  );
  double measureHeader(
    double width,
    TextScaler scaler,
    TextDirection direction,
  ) {
    double measure(String text, TextStyle style) {
      final painter = TextPainter(
        text: TextSpan(
          text: text,
          style: DefaultTextStyle.of(context).style.merge(style),
        ),
        textScaler: scaler,
        textDirection: direction,
      )..layout(maxWidth: width);
      final height = painter.height;
      painter.dispose();
      return height;
    }

    return measure(widget.chapter.volume, volumeStyle) +
        18 +
        measure(widget.chapter.title, titleStyle) +
        20 +
        2 +
        30;
  }

  Widget header() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(widget.chapter.volume, style: volumeStyle),
      const SizedBox(height: 18),
      Text(widget.chapter.title, style: titleStyle),
      const SizedBox(height: 20),
      Container(width: 28, height: 2, color: const Color(0xFFB94F3B)),
      const SizedBox(height: 30),
    ],
  );
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, viewport) {
      final width = viewport.maxWidth - 56, height = viewport.maxHeight - 48;
      final scaler = MediaQuery.textScalerOf(context),
          direction = Directionality.of(context);
      final key = (
        viewport.maxWidth,
        viewport.maxHeight,
        widget.style,
        scaler.scale(widget.style.fontSize!),
        direction,
        widget.chapter.id,
      );
      if (layoutKey != key) {
        layoutKey = key;
        pages = paginateReadingContent(
          blocks: widget.blocks,
          width: width,
          height: height,
          headerHeight: measureHeader(width, scaler, direction),
          style: widget.style,
          textScaler: scaler,
          direction: direction,
        );
        selected = (fraction * (pages.length - 1)).round().clamp(
          0,
          pages.length - 1,
        );
        final old = controller;
        controller = PageController(initialPage: selected);
        // Dispose the previous controller after its PageView detaches.
        WidgetsBinding.instance.addPostFrameCallback((_) {
          old?.dispose();
          if (mounted) widget.onPosition(fraction, selected + 1, pages.length);
        });
      }
      return CallbackShortcuts(
        bindings: {
          const SingleActivator(LogicalKeyboardKey.arrowRight): () =>
              turnPage(1),
          const SingleActivator(LogicalKeyboardKey.pageDown): () => turnPage(1),
          const SingleActivator(LogicalKeyboardKey.arrowLeft): () =>
              turnPage(-1),
          const SingleActivator(LogicalKeyboardKey.pageUp): () => turnPage(-1),
        },
        child: Focus(
          focusNode: keyboardFocus,
          autofocus: true,
          child: Listener(
            onPointerDown: (_) => keyboardFocus.requestFocus(),
            child: PageView.builder(
              key: ValueKey(layoutKey),
              controller: controller,
              itemCount: pages.length,
              onPageChanged: (page) {
                selected = page;
                fraction = pages.length <= 1 ? 0 : page / (pages.length - 1);
                widget.onPosition(fraction, page + 1, pages.length);
              },
              itemBuilder: (context, page) {
                final content = pages[page];
                return Padding(
                  padding: const EdgeInsets.fromLTRB(28, 24, 28, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      if (content.showHeader) header(),
                      for (final part in content.parts)
                        if (part.imageUrl != null)
                          Expanded(
                            child: Illustration(
                              widget.api,
                              part.imageUrl!,
                              fitPage: true,
                              restoreChrome: widget.restoreChrome,
                            ),
                          )
                        else
                          Padding(
                            padding: EdgeInsets.only(
                              bottom:
                                  part.paragraphEnd &&
                                      part != content.parts.last
                                  ? 13
                                  : 0,
                            ),
                            child: Text(part.text!, style: widget.style),
                          ),
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      );
    },
  );
}
