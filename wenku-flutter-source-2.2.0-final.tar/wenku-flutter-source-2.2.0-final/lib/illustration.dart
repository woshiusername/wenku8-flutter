import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'api.dart';
import 'widgets.dart';

class Illustration extends StatefulWidget {
  final WenkuApi api;
  final String url;
  final bool fitPage, restoreChrome;
  const Illustration(
    this.api,
    this.url, {
    this.fitPage = false,
    this.restoreChrome = true,
    super.key,
  });
  @override
  State<Illustration> createState() => _IllustrationState();
}

class _IllustrationState extends State<Illustration> {
  late Future<File> future = widget.api.image(widget.url);
  @override
  void didUpdateWidget(covariant Illustration oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.url != widget.url) future = widget.api.image(widget.url);
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<File>(
    future: future,
    builder: (context, snapshot) {
      if (snapshot.hasError) {
        return const Center(
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Text(
              '插图暂时无法加载',
              textAlign: TextAlign.center,
              style: TextStyle(color: muted, fontSize: 12),
            ),
          ),
        );
      }
      if (!snapshot.hasData) return const LoadingView();
      return InkWell(
        key: ValueKey('illustration_${widget.url}'),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute<void>(
            builder: (_) => IllustrationViewer(
              snapshot.data!,
              restoreChrome: widget.restoreChrome,
            ),
          ),
        ),
        child: Image.file(
          snapshot.data!,
          width: double.infinity,
          height: widget.fitPage ? double.infinity : null,
          fit: BoxFit.contain,
        ),
      );
    },
  );
}

class IllustrationViewer extends StatefulWidget {
  final File file;
  final bool restoreChrome;
  const IllustrationViewer(this.file, {this.restoreChrome = true, super.key});
  @override
  State<IllustrationViewer> createState() => _IllustrationViewerState();
}

class _IllustrationViewerState extends State<IllustrationViewer>
    with SingleTickerProviderStateMixin {
  final transform = TransformationController();
  late final animation = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 180),
  );
  Animation<Matrix4>? tween;
  Offset focus = Offset.zero;
  bool controls = true;
  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    animation.addListener(() {
      if (tween != null) transform.value = tween!.value;
    });
  }

  void animateTo(Matrix4 target) {
    tween = Matrix4Tween(
      begin: transform.value,
      end: target,
    ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic));
    animation.forward(from: 0);
  }

  void doubleTap() {
    if (transform.value.getMaxScaleOnAxis() > 1.1) {
      animateTo(Matrix4.identity());
    } else {
      animateTo(
        Matrix4.diagonal3Values(3, 3, 1)
          ..setTranslationRaw(-focus.dx * 2, -focus.dy * 2, 0),
      );
    }
  }

  @override
  void dispose() {
    animation.dispose();
    transform.dispose();
    SystemChrome.setEnabledSystemUIMode(
      widget.restoreChrome
          ? SystemUiMode.edgeToEdge
          : SystemUiMode.immersiveSticky,
    );
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnnotatedRegion<SystemUiOverlayStyle>(
    value: SystemUiOverlayStyle.light,
    child: Scaffold(
      backgroundColor: Colors.black,
      body: LayoutBuilder(
        builder: (context, viewport) => Stack(
          fit: StackFit.expand,
          children: [
            GestureDetector(
              onTap: () => setState(() => controls = !controls),
              onDoubleTapDown: (details) => focus = details.localPosition,
              onDoubleTap: doubleTap,
              child: InteractiveViewer(
                key: const ValueKey('illustration_viewport'),
                transformationController: transform,
                onInteractionStart: (_) => animation.stop(),
                minScale: 1,
                maxScale: 8,
                // The clipping and gesture area are the entire viewport, including letterboxing.
                boundaryMargin: EdgeInsets.symmetric(
                  horizontal: viewport.maxWidth,
                  vertical: viewport.maxHeight,
                ),
                child: SizedBox(
                  width: viewport.maxWidth,
                  height: viewport.maxHeight,
                  child: Image.file(widget.file, fit: BoxFit.contain),
                ),
              ),
            ),
            if (controls)
              Positioned(
                left: 0,
                right: 0,
                top: 0,
                child: SafeArea(
                  bottom: false,
                  child: Container(
                    color: Colors.black.withValues(alpha: .45),
                    child: Row(
                      children: [
                        IconButton(
                          tooltip: '关闭插图',
                          onPressed: () => Navigator.pop(context),
                          icon: const Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                          ),
                        ),
                        const Text(
                          '插图',
                          style: TextStyle(color: Colors.white, fontSize: 15),
                        ),
                        const Spacer(),
                        IconButton(
                          tooltip: '恢复大小',
                          onPressed: () => animateTo(Matrix4.identity()),
                          icon: const Icon(
                            Icons.fit_screen_outlined,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    ),
  );
}
