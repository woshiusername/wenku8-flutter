import 'package:flutter/material.dart';
import 'dart:io';
import 'dart:ui' show PointerDeviceKind;
import 'package:flutter/services.dart';
import 'api.dart';
import 'store.dart';
import 'screens.dart';
import 'widgets.dart';
import 'windows_backend.dart';
import 'desktop_validation.dart';

Future<void> main(List<String> arguments) async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isWindows) WenkuApi.desktop = WindowsBackend();
  final store = ReaderStore(WenkuApi());
  await store.init();
  runApp(WenkuApp(store));
  final verification = arguments.indexOf('--verify-runtime');
  if (Platform.isWindows &&
      verification >= 0 &&
      arguments.length > verification + 1) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      validateDesktop(arguments[verification + 1]);
    });
  }
}

class WenkuApp extends StatelessWidget {
  final ReaderStore store;
  const WenkuApp(this.store, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      final dark = store.dark;
      final scheme =
          ColorScheme.fromSeed(
            seedColor: vermilion,
            brightness: dark ? Brightness.dark : Brightness.light,
          ).copyWith(
            primary: dark ? const Color(0xFFE9947D) : vermilion,
            surface: dark ? const Color(0xFF202320) : paperWhite,
            onSurface: dark ? const Color(0xFFE6E5DB) : ink,
          );
      return MaterialApp(
        title: '文库',
        scrollBehavior: const MaterialScrollBehavior().copyWith(
          dragDevices: {
            PointerDeviceKind.touch,
            PointerDeviceKind.mouse,
            PointerDeviceKind.stylus,
            PointerDeviceKind.trackpad,
          },
        ),
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: scheme,
          scaffoldBackgroundColor: scheme.surface,
          appBarTheme: AppBarTheme(
            backgroundColor: scheme.surface,
            surfaceTintColor: Colors.transparent,
            elevation: 0,
            centerTitle: false,
            titleTextStyle: TextStyle(
              color: scheme.onSurface,
              fontSize: 17,
              fontWeight: FontWeight.w600,
            ),
          ),
          dividerTheme: DividerThemeData(
            color: scheme.onSurface.withValues(alpha: .09),
            thickness: 1,
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: scheme.onSurface.withValues(alpha: .04),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide.none,
            ),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 18,
              vertical: 17,
            ),
          ),
          filledButtonTheme: FilledButtonThemeData(
            style: FilledButton.styleFrom(
              minimumSize: const Size(0, 48),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(6),
              ),
              textStyle: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          outlinedButtonTheme: OutlinedButtonThemeData(
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(0, 48),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(6),
              ),
              side: BorderSide(color: scheme.onSurface.withValues(alpha: .16)),
            ),
          ),
          bottomSheetTheme: BottomSheetThemeData(
            backgroundColor: scheme.surface,
            surfaceTintColor: Colors.transparent,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            ),
          ),
        ),
        home: HomeScreen(store),
      );
    },
  );
}

class HomeScreen extends StatefulWidget {
  final ReaderStore store;
  const HomeScreen(this.store, {super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selected = 1;
  late final pages = <Widget>[
    ShelfScreen(widget.store),
    LibraryScreen(widget.store),
    LibraryScreen(widget.store, ranking: true),
    AccountScreen(widget.store),
  ];
  static const labels = ['书架', '书库', '排行', '我的'];
  static const icons = [
    Icons.bookmarks_outlined,
    Icons.auto_stories_outlined,
    Icons.bar_chart_rounded,
    Icons.person_outline_rounded,
  ];
  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 720;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: widget.store.dark
          ? SystemUiOverlayStyle.light
          : SystemUiOverlayStyle.dark,
      child: Scaffold(
        body: SafeArea(
          bottom: false,
          child: Row(
            children: [
              if (wide)
                SizedBox(
                  width: 94,
                  child: Column(
                    children: [
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 30),
                        child: Icon(
                          Icons.menu_book_rounded,
                          color: vermilion,
                          size: 30,
                        ),
                      ),
                      for (var i = 0; i < 4; i++)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 18),
                          child: InkWell(
                            onTap: () => setState(() => selected = i),
                            borderRadius: BorderRadius.circular(6),
                            child: SizedBox(
                              width: 74,
                              height: 66,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    icons[i],
                                    color: selected == i
                                        ? Theme.of(context).colorScheme.primary
                                        : muted,
                                  ),
                                  const SizedBox(height: 7),
                                  Text(
                                    labels[i],
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: selected == i
                                          ? Theme.of(
                                              context,
                                            ).colorScheme.primary
                                          : muted,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              Expanded(
                child: IndexedStack(index: selected, children: pages),
              ),
            ],
          ),
        ),
        bottomNavigationBar: wide
            ? null
            : Container(
                decoration: BoxDecoration(
                  border: Border(
                    top: BorderSide(
                      color: Theme.of(
                        context,
                      ).colorScheme.onSurface.withValues(alpha: .07),
                    ),
                  ),
                ),
                child: NavigationBar(
                  backgroundColor: Theme.of(context).colorScheme.surface,
                  surfaceTintColor: Colors.transparent,
                  indicatorColor: Theme.of(
                    context,
                  ).colorScheme.primary.withValues(alpha: .08),
                  height: 68,
                  selectedIndex: selected,
                  labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
                  onDestinationSelected: (i) => setState(() => selected = i),
                  destinations: [
                    for (var i = 0; i < 4; i++)
                      NavigationDestination(
                        icon: Icon(icons[i], size: 23),
                        label: labels[i],
                      ),
                  ],
                ),
              ),
      ),
    );
  }
}
