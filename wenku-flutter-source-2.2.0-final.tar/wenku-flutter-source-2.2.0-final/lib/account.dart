import 'package:flutter/material.dart';
import 'models.dart';
import 'store.dart';
import 'widgets.dart';
import 'screens.dart';

class AccountScreen extends StatefulWidget {
  final ReaderStore store;
  const AccountScreen(this.store, {super.key});
  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  bool busy = false;
  String status = '';
  Future<void> operation(Future<void> Function() fn) async {
    setState(() => busy = true);
    try {
      await fn();
    } catch (e) {
      if (mounted) tell(context, '$e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: widget.store,
    builder: (context, _) => WidthLimit(
      ListView(
        children: [
          const PageHeading('我的', '读书这件事，按自己的节奏来。'),
          Padding(
            padding: const EdgeInsets.fromLTRB(26, 6, 26, 28),
            child: Row(
              children: [
                Container(
                  width: 54,
                  height: 54,
                  decoration: BoxDecoration(
                    color: Theme.of(
                      context,
                    ).colorScheme.primary.withValues(alpha: .08),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.person_outline,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
                const SizedBox(width: 18),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.store.username.isEmpty
                            ? '还没有登录'
                            : widget.store.username,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 18,
                        ),
                      ),
                      const SizedBox(height: 7),
                      const Text(
                        'Wenku8 账号 · 云端书架',
                        style: TextStyle(fontSize: 11, color: muted),
                      ),
                    ],
                  ),
                ),
                if (widget.store.username.isEmpty)
                  OutlinedButton(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                        builder: (_) => LoginScreen(widget.store),
                      ),
                    ),
                    child: const Text('登录'),
                  ),
              ],
            ),
          ),
          if (widget.store.username.isNotEmpty) ...[
            ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 26),
              leading: const Icon(Icons.cloud_outlined),
              title: const Text('查看云书架'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute<void>(
                  builder: (_) => CloudShelfScreen(widget.store),
                ),
              ),
            ),
            ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 26),
              leading: const Icon(Icons.calendar_today_outlined),
              title: const Text('每日签到'),
              enabled: !busy,
              onTap: () => operation(() async {
                await widget.store.api.sign();
                if (context.mounted) tell(context, '签到成功');
              }),
            ),
            ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 26),
              leading: const Icon(Icons.account_circle_outlined),
              title: const Text('账号信息'),
              enabled: !busy,
              onTap: () => operation(() async {
                final user = await widget.store.api.user();
                if (context.mounted) {
                  await showDialog<void>(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: const Text('账号信息'),
                      content: SingleChildScrollView(
                        child: Text(
                          user.entries
                              .map((e) => '${e.key}：${e.value}')
                              .join('\n\n'),
                        ),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('关闭'),
                        ),
                      ],
                    ),
                  );
                }
              }),
            ),
          ],
          const Divider(indent: 26, endIndent: 26),
          const Padding(
            padding: EdgeInsets.fromLTRB(26, 20, 26, 12),
            child: Text('阅读偏好', style: TextStyle(color: muted, fontSize: 11)),
          ),
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 26),
            title: const Text('阅读方式'),
            leading: const Icon(Icons.swipe_outlined),
            trailing: ReadingModePicker(
              value: widget.store.readingMode,
              onChanged: (mode) {
                widget.store.readingMode = mode;
                widget.store.save();
              },
            ),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 26),
            title: const Text('深色外观'),
            secondary: const Icon(Icons.dark_mode_outlined),
            value: widget.store.dark,
            onChanged: (v) {
              widget.store.dark = v;
              widget.store.save();
            },
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 26),
            title: const Text('阅读时保持屏幕常亮'),
            secondary: const Icon(Icons.light_mode_outlined),
            value: widget.store.keepAwake,
            onChanged: (v) {
              widget.store.keepAwake = v;
              widget.store.save();
            },
          ),
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 26),
            leading: const Icon(Icons.translate_outlined),
            title: const Text('内容语言'),
            trailing: DropdownButton<int>(
              value: widget.store.api.language,
              underline: const SizedBox(),
              items: const [
                DropdownMenuItem(value: 0, child: Text('简体中文')),
                DropdownMenuItem(value: 1, child: Text('繁體中文')),
              ],
              onChanged: (v) {
                widget.store.api.language = v!;
                widget.store.save();
                tell(context, '已切换，下拉刷新书库即可加载');
              },
            ),
          ),
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 26),
            leading: const Icon(Icons.offline_pin_outlined),
            title: const Text('正文缓存'),
            subtitle: Text('${widget.store.api.cacheCount} 个章节保存在本机'),
            trailing: TextButton(
              onPressed: () async {
                final yes = await showDialog<bool>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('清理正文缓存？'),
                    content: const Text('清理后需要联网重新加载。书架和阅读进度会保留。'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text('取消'),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text('清理'),
                      ),
                    ],
                  ),
                );
                if (yes == true) {
                  await widget.store.api.clearCache();
                  if (mounted) setState(() {});
                }
              },
              child: const Text('清理'),
            ),
          ),
          const Divider(indent: 26, endIndent: 26),
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 26),
            leading: const Icon(Icons.wifi_tethering_outlined),
            title: const Text('检查服务器连接'),
            subtitle: status.isEmpty ? const Text('小说信息、目录与正文') : Text(status),
            enabled: !busy,
            onTap: () => operation(() async {
              final watch = Stopwatch()..start();
              final book = await widget.store.api.detail(1);
              final catalog = await widget.store.api.catalog(1, refresh: true);
              await widget.store.api.text(1, catalog.first.id, refresh: true);
              if (mounted) {
                setState(
                  () => status =
                      '${book.title} · ${catalog.length} 章 · 正文正常\n耗时 ${(watch.elapsedMilliseconds / 1000).toStringAsFixed(1)} 秒',
                );
              }
            }),
          ),
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 26),
            leading: const Icon(Icons.info_outline),
            title: const Text('关于'),
            trailing: const Text(
              '2.2.0',
              style: TextStyle(color: muted, fontSize: 12),
            ),
            onTap: () => showAboutDialog(
              context: context,
              applicationName: '文库',
              applicationVersion: '2.2.0',
              applicationLegalese:
                  '原作：MewX / Wenku8\n基于原客户端联网协议重构\nGPL-2.0 · 非官方 Flutter 客户端',
              children: [
                TextButton(
                  onPressed: () => widget.store.api.openUrl(
                    'https://github.com/MewX/light-novel-library_Wenku8_Android',
                  ),
                  child: const Text('原项目主页'),
                ),
              ],
            ),
          ),
          if (widget.store.username.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(26),
              child: OutlinedButton(
                onPressed: busy
                    ? null
                    : () => operation(() async {
                        await widget.store.api.logout();
                        widget.store.username = '';
                        await widget.store.save();
                      }),
                child: const Text('退出登录'),
              ),
            ),
          if (busy) const LinearProgressIndicator(minHeight: 2),
          const Padding(
            padding: EdgeInsets.fromLTRB(26, 20, 26, 35),
            child: Text(
              '文库 / WENKU8',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 10,
                height: 2,
                letterSpacing: 1,
                color: muted,
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

class LoginScreen extends StatefulWidget {
  final ReaderStore store;
  const LoginScreen(this.store, {super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final name = TextEditingController(), password = TextEditingController();
  bool busy = false, visible = false;
  String? error;
  Future<void> login() async {
    if (name.text.trim().isEmpty || password.text.isEmpty) {
      setState(() => error = '请填写账号和密码');
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await widget.store.api.login(name.text.trim(), password.text);
      widget.store.username = name.text.trim();
      password.clear();
      await widget.store.save();
      if (mounted) {
        tell(context, '登录成功');
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          error = '$e';
          busy = false;
        });
      }
    }
  }

  @override
  void dispose() {
    name.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(),
    body: WidthLimit(
      ListView(
        padding: const EdgeInsets.all(30),
        children: [
          const SizedBox(height: 35),
          const Text(
            '欢迎回来',
            style: TextStyle(fontSize: 32, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 12),
          const Text(
            '登录 Wenku8，接着读你的收藏。',
            style: TextStyle(color: muted, fontSize: 13),
          ),
          const SizedBox(height: 40),
          TextField(
            controller: name,
            enabled: !busy,
            autofillHints: const [AutofillHints.username],
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(labelText: '用户名或邮箱'),
          ),
          const SizedBox(height: 18),
          TextField(
            controller: password,
            enabled: !busy,
            obscureText: !visible,
            autofillHints: const [AutofillHints.password],
            onSubmitted: (_) => login(),
            decoration: InputDecoration(
              labelText: '密码',
              suffixIcon: IconButton(
                tooltip: '显示密码',
                onPressed: () => setState(() => visible = !visible),
                icon: Icon(
                  visible
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                ),
              ),
            ),
          ),
          if (error != null)
            Padding(
              padding: const EdgeInsets.only(top: 18),
              child: Text(
                error!,
                style: TextStyle(
                  color: Theme.of(context).colorScheme.error,
                  fontSize: 13,
                ),
              ),
            ),
          const SizedBox(height: 30),
          FilledButton(
            onPressed: busy ? null : login,
            child: busy
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text('登录'),
          ),
          const SizedBox(height: 15),
          TextButton(
            onPressed: () =>
                widget.store.api.openUrl('https://www.wenku8.net/register.php'),
            child: const Text('去 Wenku8 注册账号'),
          ),
        ],
      ),
      max: 480,
    ),
  );
}

class CloudShelfScreen extends StatefulWidget {
  final ReaderStore store;
  const CloudShelfScreen(this.store, {super.key});
  @override
  State<CloudShelfScreen> createState() => _CloudShelfScreenState();
}

class _CloudShelfScreenState extends State<CloudShelfScreen> {
  late Future<List<Novel>> future;
  @override
  void initState() {
    super.initState();
    load();
  }

  void load() {
    future = fetch();
  }

  Future<List<Novel>> fetch() async {
    final ids = await widget.store.api.cloudShelf();
    final books = <Novel>[];
    for (var i = 0; i < ids.length; i += 4) {
      books.addAll(
        await Future.wait(ids.skip(i).take(4).map(widget.store.api.detail)),
      );
    }
    return books;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('云端书架'),
      actions: [
        BookViewToggle(widget.store),
        IconButton(
          tooltip: '刷新',
          onPressed: () => setState(load),
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    body: WidthLimit(
      FutureBuilder<List<Novel>>(
        future: future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const LoadingView();
          }
          if (snapshot.hasError) {
            return FailureView(snapshot.error!, () => setState(load));
          }
          final books = snapshot.data!;
          return ListView(
            children: [
              Padding(
                padding: const EdgeInsets.all(26),
                child: Row(
                  children: [
                    Text(
                      '${books.length} 本云端收藏',
                      style: const TextStyle(color: muted),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: () async {
                        for (final book in books) {
                          await widget.store.add(book);
                        }
                        if (context.mounted) tell(context, '已全部加入本地书架');
                      },
                      child: const Text('导入本地'),
                    ),
                  ],
                ),
              ),
              BookCollection(
                widget.store,
                books,
                (n) => showBook(context, widget.store, n),
              ),
              if (books.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(40),
                  child: Center(child: Text('云端还没有收藏')),
                ),
            ],
          );
        },
      ),
    ),
  );
}
