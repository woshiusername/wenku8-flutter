import 'package:characters/characters.dart';
import 'package:flutter/painting.dart';

class ReadingBlock {
  final String? text;
  final String? imageUrl;
  const ReadingBlock.text(this.text) : imageUrl = null;
  const ReadingBlock.image(this.imageUrl) : text = null;
}

final _imageUrl = RegExp(
  r'https?://[^\s<>"\]]+\.(?:jpg|jpeg|png|webp)(?:\?[^\s<>"\]]*)?',
  caseSensitive: false,
);
final _imageMarker = RegExp(
  r'<!--\s*/?(?:image|img)\s*-->|\[/?(?:image|img)\]|</?(?:image|img)\s*>',
  caseSensitive: false,
);

List<ReadingBlock> parseReadingContent(String source) {
  // Preserve text such as the English word "image"; remove only image markup.
  final htmlImage = RegExp(
    r'''<img\b[^>]*\bsrc\s*=\s*["']([^"']+)["'][^>]*>''',
    caseSensitive: false,
  );
  final text = source
      .replaceAllMapped(htmlImage, (m) => m.group(1)!)
      .replaceAll(_imageMarker, '');
  final blocks = <ReadingBlock>[];
  void paragraphs(String value) {
    blocks.addAll(
      value
          .split(RegExp(r'\r?\n'))
          .map((p) => p.trim())
          .where((p) => p.isNotEmpty)
          .map(ReadingBlock.text),
    );
  }

  var cursor = 0;
  for (final match in _imageUrl.allMatches(text)) {
    paragraphs(text.substring(cursor, match.start));
    blocks.add(
      ReadingBlock.image(match.group(0)!.replaceFirst('http://', 'https://')),
    );
    cursor = match.end;
  }
  paragraphs(text.substring(cursor));
  return blocks;
}

class ReadingPagePart {
  final String? text, imageUrl;
  final bool paragraphEnd;
  const ReadingPagePart.text(this.text, {required this.paragraphEnd})
    : imageUrl = null;
  const ReadingPagePart.image(this.imageUrl)
    : text = null,
      paragraphEnd = false;
}

class ReadingPage {
  final List<ReadingPagePart> parts;
  final bool showHeader;
  ReadingPage(this.parts, {required this.showHeader});
}

List<ReadingPage> paginateReadingContent({
  required List<ReadingBlock> blocks,
  required double width,
  required double height,
  required double headerHeight,
  required TextStyle style,
  required TextScaler textScaler,
  required TextDirection direction,
}) {
  const gap = 13.0;
  final pages = <ReadingPage>[];
  var parts = <ReadingPagePart>[];
  var remainingHeight = height - headerHeight;
  final painter = TextPainter(textDirection: direction, textScaler: textScaler);
  double measure(String text) {
    painter.text = TextSpan(text: text, style: style);
    painter.layout(maxWidth: width);
    return painter.height;
  }

  final lineHeight = measure('文');
  void finish({bool force = false}) {
    if (parts.isNotEmpty || force) {
      pages.add(ReadingPage(List.of(parts), showHeader: pages.isEmpty));
      parts = [];
    }
    remainingHeight = height;
  }

  for (final block in blocks) {
    if (block.imageUrl != null) {
      if (parts.isNotEmpty) finish();
      parts.add(ReadingPagePart.image(block.imageUrl));
      finish();
      continue;
    }
    var chars = block.text!.characters.toList();
    while (chars.isNotEmpty) {
      if (remainingHeight + .01 < lineHeight) {
        finish(force: pages.isEmpty && parts.isEmpty);
      }
      final whole = chars.join();
      final wholeHeight = measure(whole);
      if (wholeHeight <= remainingHeight + .01) {
        parts.add(ReadingPagePart.text(whole, paragraphEnd: true));
        remainingHeight -= wholeHeight + gap;
        break;
      }
      var low = 1, high = chars.length, fit = 0;
      while (low <= high) {
        final middle = (low + high) ~/ 2;
        final candidate = chars.take(middle).join();
        if (measure(candidate) <= remainingHeight + .01) {
          fit = middle;
          low = middle + 1;
        } else {
          high = middle - 1;
        }
      }
      if (fit == 0) {
        // A tiny landscape viewport can hold the header on its own first page.
        if (parts.isNotEmpty || pages.isEmpty) {
          finish(force: true);
          continue;
        }
        fit = 1;
      }
      parts.add(
        ReadingPagePart.text(chars.take(fit).join(), paragraphEnd: false),
      );
      chars = chars.skip(fit).toList();
      finish();
    }
  }
  if (parts.isNotEmpty || pages.isEmpty) finish(force: true);
  painter.dispose();
  return pages;
}
