import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'models.dart';
import 'store.dart';
import 'api.dart';
import 'widgets.dart';
import 'reading_content.dart';
import 'reader_paging.dart';
import 'illustration.dart';
import 'vertical_reader.dart';

class ReaderScreen extends StatefulWidget {
  final ReaderStore store;
  final Novel book;
  final List<Chapter> chapters;
  final int start;
  const ReaderScreen(
    this.store,
    this.book,
    this.chapters,
    this.start, {
    super.key,
  });
  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen>
    with WidgetsBindingObserver {
  late int index = widget.start;
  final scroll = ScrollController();
  Timer? saveTimer;
  late Future<String> future;
  bool chrome = true;
  double percent = 0;
  double resumeFraction = 0;
  double? resumeOffset;
  bool restoreScroll = false, contentReady = false;
  int readingPage = 1, readingPages = 1;
  String? parsedText;
  List<ReadingBlock> blocks = [];
  Chapter get chapter => widget.chapters[index];
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    scroll.addListener(scrolled);
    WenkuApi.invokePlatform<void>('keepAwake', {
      'enabled': widget.store.keepAwake,
    });
    load(restore: true);
  }

  void load({bool restore = false, bool refresh = false}) {
    contentReady = false;
    final saved = restore ? widget.store.record(widget.book.id) : null;
    final record = saved?['cid'] == chapter.id ? saved : null;
    resumeFraction = (record?['fraction'] as num? ?? 0).toDouble().clamp(0, 1);
    resumeOffset = record != null && record['horizontal'] != true
        ? (record['offset'] as num? ?? 0).toDouble()
        : null;
    percent = resumeFraction;
    readingPage = readingPages = 1;
    restoreScroll = true;
    future = widget.store.api.text(
      widget.book.id,
      chapter.id,
      refresh: refresh,
    );
    final cid = chapter.id;
    future.then((_) {
      if (!mounted || chapter.id != cid) return;
      contentReady = true;
    }, onError: (Object _) {});
  }

  void scrolled() {
    if (!scroll.hasClients) return;
    final extent = scroll.position.maxScrollExtent;
    setState(
      () => percent = extent <= 0 ? 0 : (scroll.offset / extent).clamp(0, 1),
    );
    saveTimer?.cancel();
    saveTimer = Timer(const Duration(milliseconds: 600), saveProgress);
  }

  void saveProgress() {
    if (!contentReady) return;
    widget.store.remember(
      widget.book,
      chapter,
      scroll.hasClients ? scroll.offset : 0,
      fraction: percent,
      horizontal: widget.store.pagedReading,
    );
  }

  void changePreference(VoidCallback edit) {
    resumeFraction = percent;
    resumeOffset = null;
    restoreScroll = true;
    setState(edit);
    widget.store.save();
    saveProgress();
  }

  void pagePosition(double fraction, int page, int total) {
    if (!mounted) return;
    setState(() {
      percent = fraction;
      readingPage = page;
      readingPages = total;
    });
    saveTimer?.cancel();
    saveTimer = Timer(const Duration(milliseconds: 600), saveProgress);
  }

  void go(int target) {
    if (target < 0 || target >= widget.chapters.length) return;
    saveTimer?.cancel();
    saveProgress();
    setState(() {
      index = target;
      load();
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused) {
      saveProgress();
    }
  }

  @override
  void dispose() {
    saveTimer?.cancel();
    saveProgress();
    scroll.dispose();
    WidgetsBinding.instance.removeObserver(this);
    WenkuApi.invokePlatform<void>('keepAwake', {'enabled': false});
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void toggleChrome() {
    setState(() => chrome = !chrome);
    SystemChrome.setEnabledSystemUIMode(
      chrome ? SystemUiMode.edgeToEdge : SystemUiMode.immersiveSticky,
    );
  }

  Future<void> catalog() async {
    final selected = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * .75,
          child: Column(
            children: [
              const Padding(
                padding: EdgeInsets.all(22),
                child: Text(
                  '章节目录',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: widget.chapters.length,
                  itemBuilder: (context, i) {
                    final c = widget.chapters[i];
                    return ListTile(
                      selected: i == index,
                      dense: true,
                      title: Text(
                        c.title,
                        style: const TextStyle(fontSize: 13, height: 1.6),
                      ),
                      subtitle:
                          i == 0 || widget.chapters[i - 1].volume != c.volume
                          ? Text(c.volume, style: const TextStyle(fontSize: 10))
                          : null,
                      trailing: i == index
                          ? const Icon(Icons.bookmark, size: 16)
                          : null,
                      onTap: () => Navigator.pop(context, i),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (selected != null && mounted) go(selected);
  }

  Future<void> settings() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => StatefulBuilder(
        builder: (context, update) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(26, 22, 26, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '阅读设置',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 22),
                Row(
                  children: [
                    const Text('阅读方式', style: TextStyle(fontSize: 13)),
                    const Spacer(),
                    ReadingModePicker(
                      value: widget.store.readingMode,
                      onChanged: (mode) {
                        changePreference(() => widget.store.readingMode = mode);
                        update(() {});
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Text(
                      '字号',
                      style: TextStyle(fontSize: 12, color: muted),
                    ),
                    Expanded(
                      child: Slider(
                        min: 14,
                        max: 30,
                        divisions: 16,
                        value: widget.store.fontSize,
                        onChanged: (v) {
                          changePreference(() => widget.store.fontSize = v);
                          update(() {});
                        },
                      ),
                    ),
                    Text(
                      '${widget.store.fontSize.round()}',
                      style: const TextStyle(fontSize: 12),
                    ),
                  ],
                ),
                Row(
                  children: [
                    const Text(
                      '行距',
                      style: TextStyle(fontSize: 12, color: muted),
                    ),
                    Expanded(
                      child: Slider(
                        min: 1.4,
                        max: 2.4,
                        divisions: 10,
                        value: widget.store.lineHeight,
                        onChanged: (v) {
                          changePreference(() => widget.store.lineHeight = v);
                          update(() {});
                        },
                      ),
                    ),
                    Text(
                      widget.store.lineHeight.toStringAsFixed(1),
                      style: const TextStyle(fontSize: 12),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    for (var i = 0; i < 4; i++)
                      InkWell(
                        onTap: () {
                          changePreference(() => widget.store.paper = i);
                          update(() {});
                        },
                        child: Column(
                          children: [
                            Container(
                              width: 52,
                              height: 42,
                              decoration: BoxDecoration(
                                color: [
                                  paperWhite,
                                  const Color(0xFFEDE3CC),
                                  const Color(0xFFDCE4D8),
                                  const Color(0xFF202320),
                                ][i],
                                borderRadius: BorderRadius.circular(5),
                                border: Border.all(
                                  color: widget.store.paper == i
                                      ? vermilion
                                      : muted.withValues(alpha: .25),
                                  width: widget.store.paper == i ? 2 : 1,
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  '文',
                                  style: TextStyle(
                                    color: i == 3 ? Colors.white70 : ink,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 7),
                            Text(
                              ['白纸', '暖纸', '青纸', '夜读'][i],
                              style: const TextStyle(
                                fontSize: 11,
                                color: muted,
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> content(String text, Color foreground) {
    return [
      for (final block in blocks)
        if (block.imageUrl != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Illustration(
              widget.store.api,
              block.imageUrl!,
              restoreChrome: chrome,
            ),
          )
        else
          Padding(
            padding: const EdgeInsets.only(bottom: 13),
            child: Text(
              block.text!,
              style: TextStyle(
                fontSize: widget.store.fontSize,
                height: widget.store.lineHeight,
                color: foreground,
                letterSpacing: .35,
              ),
            ),
          ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final night = widget.store.paper == 3;
    final background = [
      paperWhite,
      const Color(0xFFF0E7D4),
      const Color(0xFFE5EBDF),
      const Color(0xFF202320),
    ][widget.store.paper];
    final foreground = night
        ? const Color(0xFFD6D8CF)
        : const Color(0xFF383B32);
    return PopScope(
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) saveProgress();
      },
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: night ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
        child: Scaffold(
          backgroundColor: background,
          appBar: chrome
              ? AppBar(
                  backgroundColor: background,
                  foregroundColor: foreground,
                  title: Text(
                    widget.book.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: foreground, fontSize: 13),
                  ),
                  actions: [
                    IconButton(
                      tooltip: '章节目录',
                      onPressed: catalog,
                      icon: const Icon(Icons.format_list_bulleted),
                    ),
                    IconButton(
                      tooltip: '阅读设置',
                      onPressed: settings,
                      icon: const Icon(Icons.text_fields),
                    ),
                  ],
                )
              : null,
          body: SafeArea(
            child: GestureDetector(
              behavior: HitTestBehavior.translucent,
              onTap: toggleChrome,
              child: WidthLimit(
                FutureBuilder<String>(
                  future: future,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState != ConnectionState.done) {
                      return const LoadingView();
                    }
                    if (snapshot.hasError) {
                      return FailureView(
                        snapshot.error!,
                        () => setState(() => load(refresh: true)),
                      );
                    }
                    if (parsedText != snapshot.data) {
                      parsedText = snapshot.data;
                      blocks = parseReadingContent(snapshot.data!);
                    }
                    if (widget.store.readingMode == ReadingMode.vertical) {
                      return VerticalChapter(
                        key: ValueKey('chapter_${chapter.id}'),
                        api: widget.store.api,
                        chapter: chapter,
                        blocks: blocks,
                        style: DefaultTextStyle.of(context).style.merge(
                          TextStyle(
                            fontSize: widget.store.fontSize,
                            color: foreground,
                          ),
                        ),
                        lineHeight: widget.store.lineHeight,
                        initialFraction: resumeFraction,
                        onPosition: pagePosition,
                        restoreChrome: chrome,
                      );
                    }
                    if (widget.store.horizontalReading) {
                      return PagedChapter(
                        key: ValueKey('chapter_${chapter.id}'),
                        api: widget.store.api,
                        chapter: chapter,
                        blocks: blocks,
                        style: DefaultTextStyle.of(context).style.merge(
                          TextStyle(
                            fontSize: widget.store.fontSize,
                            height: widget.store.lineHeight,
                            color: foreground,
                            letterSpacing: .35,
                          ),
                        ),
                        foreground: foreground,
                        initialFraction: resumeFraction,
                        onPosition: pagePosition,
                        restoreChrome: chrome,
                      );
                    }
                    if (restoreScroll) {
                      restoreScroll = false;
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        if (!mounted || !scroll.hasClients) return;
                        final offset =
                            resumeOffset ??
                            resumeFraction * scroll.position.maxScrollExtent;
                        scroll.jumpTo(
                          offset.clamp(0, scroll.position.maxScrollExtent),
                        );
                        saveProgress();
                      });
                    }
                    final items = content(snapshot.data!, foreground);
                    return ListView(
                      controller: scroll,
                      key: ValueKey('chapter_${chapter.id}'),
                      padding: const EdgeInsets.fromLTRB(28, 28, 28, 40),
                      children: [
                        Text(
                          chapter.volume,
                          style: TextStyle(
                            fontSize: 11,
                            height: 1.8,
                            letterSpacing: 1,
                            color: foreground.withValues(alpha: .5),
                          ),
                        ),
                        const SizedBox(height: 18),
                        Text(
                          chapter.title,
                          style: TextStyle(
                            fontSize: 26,
                            height: 1.6,
                            fontWeight: FontWeight.w600,
                            color: foreground,
                          ),
                        ),
                        const SizedBox(height: 20),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Container(
                            width: 28,
                            height: 2,
                            color: vermilion,
                          ),
                        ),
                        const SizedBox(height: 30),
                        SelectionArea(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: items,
                          ),
                        ),
                        const SizedBox(height: 25),
                        TextButton(
                          onPressed: index + 1 < widget.chapters.length
                              ? () => go(index + 1)
                              : null,
                          child: Text(
                            index + 1 < widget.chapters.length
                                ? '下一章 →'
                                : '已经读到最后一章',
                          ),
                        ),
                      ],
                    );
                  },
                ),
                max: 760,
              ),
            ),
          ),
          bottomNavigationBar: chrome
              ? SafeArea(
                  child: Container(
                    color: background,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 15,
                      vertical: 4,
                    ),
                    child: Row(
                      children: [
                        IconButton(
                          key: const ValueKey('previous_chapter'),
                          tooltip: '上一章',
                          onPressed: index > 0 ? () => go(index - 1) : null,
                          icon: Icon(
                            widget.store.pagedReading
                                ? Icons.skip_previous_rounded
                                : Icons.chevron_left,
                          ),
                          color: foreground,
                        ),
                        Expanded(
                          child: Text(
                            widget.store.pagedReading
                                ? '${index + 1} / ${widget.chapters.length}  ·  第 $readingPage / $readingPages 页'
                                : '${index + 1} / ${widget.chapters.length}  ·  本章 ${(percent * 100).round()}%',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 11,
                              color: foreground.withValues(alpha: .55),
                            ),
                          ),
                        ),
                        IconButton(
                          key: const ValueKey('next_chapter'),
                          tooltip: '下一章',
                          onPressed: index + 1 < widget.chapters.length
                              ? () => go(index + 1)
                              : null,
                          icon: Icon(
                            widget.store.pagedReading
                                ? Icons.skip_next_rounded
                                : Icons.chevron_right,
                          ),
                          color: foreground,
                        ),
                      ],
                    ),
                  ),
                )
              : null,
        ),
      ),
    );
  }
}
