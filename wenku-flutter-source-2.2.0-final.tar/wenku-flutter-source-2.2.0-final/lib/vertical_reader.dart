import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'api.dart';
import 'illustration.dart';
import 'models.dart';
import 'reading_content.dart';

enum VerticalOrientation { upright, sideways, compact }

class VerticalRun {
  final String source, display;
  final VerticalOrientation orientation;
  const VerticalRun(this.source, this.display, this.orientation);
}

const verticalPunctuation = {
  '，': '︐',
  '、': '︑',
  '。': '︒',
  '：': '︓',
  '；': '︔',
  '！': '︕',
  '？': '︖',
  '「': '﹁',
  '」': '﹂',
  '『': '﹃',
  '』': '﹄',
  '“': '﹁',
  '”': '﹂',
  '（': '︵',
  '）': '︶',
  '(': '︵',
  ')': '︶',
  '【': '︻',
  '】': '︼',
  '《': '︽',
  '》': '︾',
};
List<VerticalRun> verticalRuns(String text) {
  final chars = text.characters.toList(), runs = <VerticalRun>[];
  final latinStart = RegExp(r'^[A-Za-z0-9]$'),
      latin = RegExp(r"^[A-Za-z0-9._'/-]$");
  for (var i = 0; i < chars.length;) {
    final char = chars[i];
    if (latinStart.hasMatch(char)) {
      var end = i + 1;
      while (end < chars.length && latin.hasMatch(chars[end])) {
        end++;
      }
      final word = chars.sublist(i, end).join();
      if (RegExp(r'^\d{1,2}$').hasMatch(word)) {
        runs.add(VerticalRun(word, word, VerticalOrientation.compact));
      } else if (RegExp(r'^[A-Z]{1,4}$').hasMatch(word)) {
        runs.addAll(
          word.characters.map(
            (c) => VerticalRun(c, c, VerticalOrientation.upright),
          ),
        );
      } else {
        runs.add(VerticalRun(word, word, VerticalOrientation.sideways));
      }
      i = end;
    } else {
      final sideways = 'ー—―─…⋯～~'.contains(char);
      runs.add(
        VerticalRun(
          char,
          verticalPunctuation[char] ?? char,
          sideways ? VerticalOrientation.sideways : VerticalOrientation.upright,
        ),
      );
      i++;
    }
  }
  return runs;
}

class VerticalPlacement {
  final VerticalRun run;
  final Offset position;
  final double extent;
  const VerticalPlacement(this.run, this.position, this.extent);
}

class VerticalPage {
  final List<VerticalPlacement> placements;
  final String? imageUrl;
  const VerticalPage(this.placements, {this.imageUrl});
}

List<VerticalPage> paginateVertical({
  required List<ReadingBlock> blocks,
  required Size size,
  required TextStyle style,
  required TextScaler scaler,
  required double lineHeight,
}) {
  final font = scaler.scale(style.fontSize!),
      step = font * 1.2,
      stride = math.max(font * 1.25, font * lineHeight);
  final columns = math.max(1, (size.width / stride).floor());
  final pages = <VerticalPage>[];
  var placements = <VerticalPlacement>[], column = 0;
  var y = 0.0;
  final painter = TextPainter(
    textDirection: TextDirection.ltr,
    textScaler: scaler,
  );
  double length(VerticalRun run) {
    if (run.orientation != VerticalOrientation.sideways) {
      return run.source.trim().isEmpty ? step * .5 : step;
    }
    painter.text = TextSpan(
      text: run.display,
      style: style.copyWith(height: 1, letterSpacing: 0),
    );
    painter.layout();
    return math.max(step, painter.width);
  }

  void finish() {
    if (placements.isNotEmpty) {
      pages.add(VerticalPage(List.of(placements)));
      placements = [];
    }
    column = 0;
    y = 0;
  }

  void nextColumn() {
    column++;
    y = 0;
    if (column >= columns) finish();
  }

  for (final block in blocks) {
    if (block.imageUrl != null) {
      finish();
      pages.add(VerticalPage(const [], imageUrl: block.imageUrl));
      continue;
    }
    for (final original in verticalRuns(block.text!)) {
      final pending = <VerticalRun>[original];
      while (pending.isNotEmpty) {
        var run = pending.removeAt(0), extent = length(run);
        if (extent > size.height && run.source.characters.length > 1) {
          final chars = run.source.characters.toList();
          var low = 1, high = chars.length, fit = 1;
          while (low <= high) {
            final mid = (low + high) ~/ 2;
            final candidate = VerticalRun(
              chars.take(mid).join(),
              chars.take(mid).join(),
              run.orientation,
            );
            if (length(candidate) <= size.height) {
              fit = mid;
              low = mid + 1;
            } else {
              high = mid - 1;
            }
          }
          final head = chars.take(fit).join(), tail = chars.skip(fit).join();
          run = VerticalRun(head, head, run.orientation);
          extent = length(run);
          if (tail.isNotEmpty) {
            pending.insert(0, VerticalRun(tail, tail, run.orientation));
          }
        }
        if (y + extent > size.height + .01 && y > 0) nextColumn();
        placements.add(
          VerticalPlacement(
            run,
            Offset(size.width - (column + .5) * stride, y),
            extent,
          ),
        );
        y += extent;
      }
    }
    if (y > 0) nextColumn();
  }
  finish();
  painter.dispose();
  return pages.isEmpty ? [const VerticalPage([])] : pages;
}

class VerticalPagePainter extends CustomPainter {
  final VerticalPage page;
  final TextStyle style;
  final TextScaler scaler;
  const VerticalPagePainter(this.page, this.style, this.scaler);
  @override
  void paint(Canvas canvas, Size size) {
    final cell = scaler.scale(style.fontSize!) * 1.2;
    final painter = TextPainter(
      textDirection: TextDirection.ltr,
      textScaler: scaler,
    );
    for (final item in page.placements) {
      painter.text = TextSpan(
        text: item.run.display,
        style: style.copyWith(height: 1, letterSpacing: 0),
      );
      painter.layout();
      canvas.save();
      if (item.run.orientation == VerticalOrientation.sideways) {
        canvas.translate(
          item.position.dx + painter.height / 2,
          item.position.dy + (item.extent - painter.width) / 2,
        );
        canvas.rotate(math.pi / 2);
        painter.paint(canvas, Offset.zero);
      } else {
        final scale = math.min(1.0, cell / math.max(painter.width, 1));
        canvas.translate(
          item.position.dx - painter.width * scale / 2,
          item.position.dy + (item.extent - painter.height * scale) / 2,
        );
        canvas.scale(scale);
        painter.paint(canvas, Offset.zero);
      }
      canvas.restore();
    }
    painter.dispose();
  }

  @override
  bool shouldRepaint(covariant VerticalPagePainter old) =>
      old.page != page || old.style != style || old.scaler != scaler;
}

class VerticalChapter extends StatefulWidget {
  final WenkuApi api;
  final Chapter chapter;
  final List<ReadingBlock> blocks;
  final TextStyle style;
  final double lineHeight, initialFraction;
  final bool restoreChrome;
  final void Function(double fraction, int page, int total) onPosition;
  const VerticalChapter({
    required this.api,
    required this.chapter,
    required this.blocks,
    required this.style,
    required this.lineHeight,
    required this.initialFraction,
    required this.restoreChrome,
    required this.onPosition,
    super.key,
  });
  @override
  State<VerticalChapter> createState() => _VerticalChapterState();
}

class _VerticalChapterState extends State<VerticalChapter> {
  final focus = FocusNode(debugLabel: 'Vertical reading');
  PageController? controller;
  List<VerticalPage> pages = [];
  Object? layoutKey;
  late double fraction = widget.initialFraction;
  int selected = 0;
  @override
  void dispose() {
    controller?.dispose();
    focus.dispose();
    super.dispose();
  }

  void flip(int delta) {
    if (controller?.hasClients == true) {
      controller!.animateToPage(
        (selected + delta).clamp(0, pages.length - 1),
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, viewport) {
      final size = Size(viewport.maxWidth - 56, viewport.maxHeight - 56);
      final scaler = MediaQuery.textScalerOf(context);
      final key = (
        size,
        widget.style,
        scaler.scale(widget.style.fontSize!),
        widget.lineHeight,
        widget.chapter.id,
      );
      if (layoutKey != key) {
        layoutKey = key;
        pages = paginateVertical(
          blocks: widget.blocks,
          size: size,
          style: widget.style,
          scaler: scaler,
          lineHeight: widget.lineHeight,
        );
        selected = (fraction * (pages.length - 1)).round().clamp(
          0,
          pages.length - 1,
        );
        final old = controller;
        controller = PageController(initialPage: selected);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          old?.dispose();
          if (mounted) widget.onPosition(fraction, selected + 1, pages.length);
        });
      }
      return CallbackShortcuts(
        bindings: {
          const SingleActivator(LogicalKeyboardKey.arrowLeft): () => flip(1),
          const SingleActivator(LogicalKeyboardKey.arrowRight): () => flip(-1),
          const SingleActivator(LogicalKeyboardKey.pageDown): () => flip(1),
          const SingleActivator(LogicalKeyboardKey.pageUp): () => flip(-1),
        },
        child: Focus(
          focusNode: focus,
          autofocus: true,
          child: Listener(
            onPointerDown: (_) => focus.requestFocus(),
            child: PageView.builder(
              key: ValueKey(layoutKey),
              reverse: true,
              controller: controller,
              itemCount: pages.length,
              onPageChanged: (page) {
                selected = page;
                fraction = pages.length <= 1 ? 0 : page / (pages.length - 1);
                widget.onPosition(fraction, page + 1, pages.length);
              },
              itemBuilder: (context, index) {
                final page = pages[index];
                return Padding(
                  padding: const EdgeInsets.all(28),
                  child: page.imageUrl != null
                      ? Illustration(
                          widget.api,
                          page.imageUrl!,
                          fitPage: true,
                          restoreChrome: widget.restoreChrome,
                        )
                      : Semantics(
                          label: page.placements
                              .map((p) => p.run.source)
                              .join(),
                          child: ClipRect(
                            child: CustomPaint(
                              key: ValueKey('vertical_page_$index'),
                              painter: VerticalPagePainter(
                                page,
                                widget.style,
                                scaler,
                              ),
                              size: Size.infinite,
                            ),
                          ),
                        ),
                );
              },
            ),
          ),
        ),
      );
    },
  );
}
