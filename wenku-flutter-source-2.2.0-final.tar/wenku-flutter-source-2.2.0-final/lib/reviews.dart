import 'dart:async';
import 'package:flutter/material.dart';
import 'models.dart';
import 'store.dart';
import 'widgets.dart';
import 'account.dart';

class ReviewsScreen extends StatefulWidget {
  final ReaderStore store;
  final int id;
  final String title;
  final bool replies;
  const ReviewsScreen(
    this.store,
    this.id,
    this.title, {
    this.replies = false,
    super.key,
  });
  @override
  State<ReviewsScreen> createState() => _ReviewsScreenState();
}

class _ReviewsScreenState extends State<ReviewsScreen> {
  late Future<List<Review>> future;
  int page = 1;
  bool posting = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  void load() {
    future = widget.replies
        ? widget.store.api.replies(widget.id, page)
        : widget.store.api.reviews(widget.id, page);
  }

  Future<void> compose() async {
    if (widget.store.username.isEmpty) {
      await Navigator.push(
        context,
        MaterialPageRoute<void>(builder: (_) => LoginScreen(widget.store)),
      );
      if (!mounted || widget.store.username.isEmpty) return;
    }
    final title = TextEditingController(), text = TextEditingController();
    final submit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(widget.replies ? '回复书评' : '写一条书评'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!widget.replies)
                TextField(
                  controller: title,
                  maxLength: 60,
                  decoration: const InputDecoration(labelText: '标题'),
                ),
              const SizedBox(height: 12),
              TextField(
                controller: text,
                minLines: 4,
                maxLines: 8,
                maxLength: 2000,
                decoration: const InputDecoration(labelText: '正文'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () {
              if (text.text.trim().isNotEmpty &&
                  (widget.replies || title.text.trim().isNotEmpty)) {
                Navigator.pop(context, true);
              }
            },
            child: const Text('发表'),
          ),
        ],
      ),
    );
    final subject = title.text.trim(), content = text.text.trim();
    await Future<void>.delayed(const Duration(milliseconds: 250));
    title.dispose();
    text.dispose();
    if (submit != true || !mounted) return;
    setState(() => posting = true);
    try {
      if (widget.replies) {
        await widget.store.api.reply(widget.id, content);
      } else {
        await widget.store.api.postReview(widget.id, subject, content);
      }
      if (mounted) {
        tell(context, '发表成功');
        setState(() {
          page = 1;
          load();
        });
      }
    } catch (e) {
      if (mounted) tell(context, '$e');
    } finally {
      if (mounted) setState(() => posting = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.replies ? '书评回复' : '书评'),
      actions: [
        IconButton(
          tooltip: '发表',
          onPressed: posting ? null : compose,
          icon: const Icon(Icons.edit_outlined),
        ),
      ],
    ),
    body: WidthLimit(
      ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(26),
            child: Text(
              widget.title,
              maxLines: 2,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w600,
                height: 1.5,
              ),
            ),
          ),
          if (posting) const LinearProgressIndicator(minHeight: 2),
          FutureBuilder<List<Review>>(
            future: future,
            builder: (context, snapshot) {
              if (snapshot.connectionState != ConnectionState.done) {
                return const LoadingView();
              }
              if (snapshot.hasError) {
                return FailureView(snapshot.error!, () => setState(load));
              }
              return Column(
                children: [
                  for (final review in snapshot.data!)
                    InkWell(
                      onTap: widget.replies
                          ? null
                          : () => Navigator.push(
                              context,
                              MaterialPageRoute<void>(
                                builder: (_) => ReviewsScreen(
                                  widget.store,
                                  review.id,
                                  review.content,
                                  replies: true,
                                ),
                              ),
                            ),
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(26, 16, 26, 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    review.user,
                                    style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                                Text(
                                  review.displayDate,
                                  style: const TextStyle(
                                    fontSize: 10,
                                    color: muted,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Text(
                              review.content,
                              style: const TextStyle(fontSize: 14, height: 1.9),
                            ),
                            const SizedBox(height: 12),
                            if (!widget.replies)
                              Text(
                                '${review.replies} 条回复',
                                style: const TextStyle(
                                  color: muted,
                                  fontSize: 11,
                                ),
                              ),
                            const SizedBox(height: 14),
                            const Divider(),
                          ],
                        ),
                      ),
                    ),
                  if (snapshot.data!.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(30),
                      child: Text('这里还没有书评'),
                    ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TextButton(
                        onPressed: page > 1
                            ? () => setState(() {
                                page--;
                                load();
                              })
                            : null,
                        child: const Text('上一页'),
                      ),
                      Text('$page', style: const TextStyle(color: muted)),
                      TextButton(
                        onPressed: snapshot.data!.isNotEmpty
                            ? () => setState(() {
                                page++;
                                load();
                              })
                            : null,
                        child: const Text('下一页'),
                      ),
                    ],
                  ),
                ],
              );
            },
          ),
          const SizedBox(height: 30),
        ],
      ),
      max: 760,
    ),
  );
}
