import 'package:flutter/material.dart';
import 'models.dart';
import 'api.dart';
import 'store.dart';

const ink = Color(0xFF292C29);
const muted = Color(0xFF85877F);
const vermilion = Color(0xFFB94F3B);
const paperWhite = Color(0xFFF7F6F2);

void tell(BuildContext context, String message) {
  ScaffoldMessenger.of(context).hideCurrentSnackBar();
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message),
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 4),
    ),
  );
}

class PageHeading extends StatelessWidget {
  final String title;
  final List<Widget> actions;
  const PageHeading(this.title, String _, {this.actions = const [], super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(26, 28, 18, 22),
    child: Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 32,
                  height: 1.2,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -1,
                ),
              ),
            ],
          ),
        ),
        ...actions,
      ],
    ),
  );
}

class BookCover extends StatefulWidget {
  final Novel book;
  final double? width, height;
  const BookCover(this.book, {this.width, this.height, super.key});
  @override
  State<BookCover> createState() => _BookCoverState();
}

class _BookCoverState extends State<BookCover> {
  late final image = WenkuApi().image(widget.book.cover);
  Novel get book => widget.book;
  @override
  Widget build(BuildContext context) => Semantics(
    label: '${book.title} 封面',
    image: true,
    child: Container(
      width: widget.width,
      height: widget.height,
      decoration: BoxDecoration(
        color: const Color(0xFFE5E3DC),
        borderRadius: BorderRadius.circular(4),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: .09),
            blurRadius: 9,
            offset: const Offset(1, 4),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: FutureBuilder(
        future: image,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return Image.file(snapshot.data!, fit: BoxFit.cover);
          }
          if (!snapshot.hasError) {
            return Center(
              child: Icon(
                Icons.auto_stories_outlined,
                color: ink.withValues(alpha: .18),
              ),
            );
          }
          return Padding(
            padding: const EdgeInsets.all(12),
            child: Center(
              child: Text(
                book.title,
                textAlign: TextAlign.center,
                maxLines: 6,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: ink, fontSize: 13, height: 1.6),
              ),
            ),
          );
        },
      ),
    ),
  );
}

class BookGrid extends StatelessWidget {
  final List<Novel> books;
  final void Function(Novel) onTap;
  final String Function(Novel)? caption;
  const BookGrid(this.books, this.onTap, {this.caption, super.key});
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final width = constraints.maxWidth;
      final columns = width < 350
          ? 2
          : width < 530
          ? 3
          : width < 850
          ? 4
          : 5;
      final cellWidth = (width - 52 - (columns - 1) * 18) / columns;
      return GridView.builder(
        padding: const EdgeInsets.fromLTRB(26, 6, 26, 30),
        itemCount: books.length,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: columns,
          crossAxisSpacing: 18,
          mainAxisSpacing: 24,
          mainAxisExtent: cellWidth * 1.42 + 78,
        ),
        itemBuilder: (context, i) {
          final book = books[i];
          return InkWell(
            key: ValueKey('book_${book.id}'),
            borderRadius: BorderRadius.circular(4),
            onTap: () => onTap(book),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: cellWidth * 1.42,
                  width: double.infinity,
                  child: BookCover(book),
                ),
                const SizedBox(height: 10),
                Text(
                  book.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13,
                    height: 1.45,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  caption?.call(book) ?? book.author,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 10, color: muted),
                ),
              ],
            ),
          );
        },
      );
    },
  );
}

class BookViewToggle extends StatelessWidget {
  final ReaderStore store;
  const BookViewToggle(this.store, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) => IconButton(
      key: const ValueKey('book_view_toggle'),
      tooltip: store.bookList ? '切换为封面网格' : '切换为列表',
      icon: Icon(
        store.bookList ? Icons.grid_view_outlined : Icons.view_list_outlined,
      ),
      onPressed: () {
        store.bookList = !store.bookList;
        store.save();
      },
    ),
  );
}

class BookCollection extends StatelessWidget {
  final ReaderStore store;
  final List<Novel> books;
  final void Function(Novel) onTap;
  final String Function(Novel)? caption;
  const BookCollection(
    this.store,
    this.books,
    this.onTap, {
    this.caption,
    super.key,
  });
  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      if (!store.bookList) return BookGrid(books, onTap, caption: caption);
      return ListView.separated(
        key: const ValueKey('book_list'),
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(26, 2, 26, 26),
        itemCount: books.length,
        separatorBuilder: (_, _) => const Divider(height: 28),
        itemBuilder: (context, index) {
          final book = books[index];
          return InkWell(
            key: ValueKey('book_${book.id}'),
            onTap: () => onTap(book),
            borderRadius: BorderRadius.circular(4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BookCover(book, width: 66, height: 94),
                const SizedBox(width: 18),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        book.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 15,
                          height: 1.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        [
                          book.author,
                          book.status,
                        ].where((e) => e.isNotEmpty).join(' · '),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11, color: muted),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        caption?.call(book) ??
                            (book.intro.isNotEmpty ? book.intro : book.tags),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 11,
                          height: 1.6,
                          color: muted,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                const Icon(Icons.chevron_right, size: 18, color: muted),
              ],
            ),
          );
        },
      );
    },
  );
}

class ReadingModePicker extends StatelessWidget {
  final ReadingMode value;
  final ValueChanged<ReadingMode> onChanged;
  const ReadingModePicker({
    required this.value,
    required this.onChanged,
    super.key,
  });
  @override
  Widget build(BuildContext context) => DropdownButton<ReadingMode>(
    key: const ValueKey('reading_mode_picker'),
    value: value,
    underline: const SizedBox(),
    items: [
      for (final mode in ReadingMode.values)
        DropdownMenuItem(
          value: mode,
          child: Text(mode.label, style: const TextStyle(fontSize: 13)),
        ),
    ],
    onChanged: (mode) {
      if (mode != null) onChanged(mode);
    },
  );
}

class FailureView extends StatelessWidget {
  final Object error;
  final VoidCallback retry;
  const FailureView(this.error, this.retry, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(36),
    child: Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.cloud_off_outlined, color: muted, size: 34),
          const SizedBox(height: 18),
          const Text(
            '暂时没有加载成功',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 10),
          Text(
            '$error',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, color: muted, height: 1.7),
          ),
          const SizedBox(height: 20),
          OutlinedButton(onPressed: retry, child: const Text('重新加载')),
        ],
      ),
    ),
  );
}

class LoadingView extends StatelessWidget {
  const LoadingView({super.key});
  @override
  Widget build(BuildContext context) => const Padding(
    padding: EdgeInsets.all(70),
    child: Center(
      child: SizedBox(
        width: 23,
        height: 23,
        child: CircularProgressIndicator(strokeWidth: 2),
      ),
    ),
  );
}

class FilterStrip extends StatelessWidget {
  final List<String> labels;
  final int selected;
  final ValueChanged<int> onChanged;
  const FilterStrip(this.labels, this.selected, this.onChanged, {super.key});
  @override
  Widget build(BuildContext context) => SizedBox(
    height: 49,
    child: ListView.separated(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 26),
      itemCount: labels.length,
      separatorBuilder: (_, _) => const SizedBox(width: 26),
      itemBuilder: (context, i) => InkWell(
        onTap: () => onChanged(i),
        child: Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: i == selected
                    ? Theme.of(context).colorScheme.primary
                    : Colors.transparent,
                width: 2,
              ),
            ),
          ),
          child: Text(
            labels[i],
            style: TextStyle(
              fontSize: 14,
              fontWeight: i == selected ? FontWeight.w600 : FontWeight.w400,
              color: i == selected
                  ? Theme.of(context).colorScheme.onSurface
                  : muted,
            ),
          ),
        ),
      ),
    ),
  );
}

class WidthLimit extends StatelessWidget {
  final Widget child;
  final double max;
  const WidthLimit(this.child, {this.max = 1100, super.key});
  @override
  Widget build(BuildContext context) => Align(
    alignment: Alignment.topCenter,
    child: ConstrainedBox(
      constraints: BoxConstraints(maxWidth: max),
      child: child,
    ),
  );
}
