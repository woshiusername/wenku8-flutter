import 'dart:async';
import 'package:flutter/material.dart';
import 'api.dart';
import 'models.dart';
import 'store.dart';
import 'widgets.dart';
import 'reader.dart';
import 'reading_content.dart';
import 'account.dart';
import 'reviews.dart';
export 'account.dart';

void showBook(BuildContext context, ReaderStore store, Novel book) =>
    Navigator.push(
      context,
      MaterialPageRoute<void>(builder: (_) => DetailScreen(store, book)),
    );

class LibraryScreen extends StatefulWidget {
  final ReaderStore store;
  final bool ranking;
  const LibraryScreen(this.store, {this.ranking = false, super.key});
  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  int filter = 0, page = 1;
  late Future<BookPage> future;
  final scroll = ScrollController();
  List<String> get names => widget.ranking
      ? ['总点击', '月点击', '周点击', '日点击', '总推荐', '月推荐', '周推荐', '日推荐', '收藏榜', '字数榜']
      : ['最近更新', '新书入库', '收藏最多', '已完结'];
  List<String> get sorts => widget.ranking
      ? [
          'allvisit',
          'monthvisit',
          'weekvisit',
          'dayvisit',
          'allvote',
          'monthvote',
          'weekvote',
          'dayvote',
          'goodnum',
          'size',
        ]
      : ['lastupdate', 'postdate', 'goodnum', 'fullflag'];
  @override
  void initState() {
    super.initState();
    load();
  }

  void load() {
    future = widget.store.api.list(sorts[filter], page);
  }

  void reload() => setState(load);
  void changePage(int value) {
    setState(() {
      page = value;
      load();
    });
    if (scroll.hasClients) scroll.jumpTo(0);
  }

  @override
  void dispose() {
    scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => WidthLimit(
    Column(
      children: [
        PageHeading(
          widget.ranking ? '排行榜' : '书库',
          widget.ranking ? '从读者的选择里，找到下一本。' : '翻开一本书，故事就开始了。',
          actions: [
            if (!widget.ranking) BookViewToggle(widget.store),
            IconButton(
              tooltip: '搜索小说',
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute<void>(
                  builder: (_) => SearchScreen(widget.store),
                ),
              ),
              icon: const Icon(Icons.search_rounded, size: 27),
            ),
          ],
        ),
        FilterStrip(names, filter, (i) {
          setState(() {
            filter = i;
            page = 1;
            load();
          });
          if (scroll.hasClients) scroll.jumpTo(0);
        }),
        const SizedBox(height: 12),
        Expanded(
          child: RefreshIndicator(
            onRefresh: () async {
              reload();
              await future;
            },
            child: ListView(
              controller: scroll,
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                FutureBuilder<BookPage>(
                  future: future,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState != ConnectionState.done) {
                      return const LoadingView();
                    }
                    if (snapshot.hasError) {
                      return FailureView(snapshot.error!, reload);
                    }
                    final result = snapshot.data!;
                    return Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(26, 4, 26, 16),
                          child: Row(
                            children: [
                              const Spacer(),
                              Text(
                                '第 $page / ${result.pages} 页',
                                style: const TextStyle(
                                  fontSize: 11,
                                  color: muted,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (result.books.isEmpty)
                          const Padding(
                            padding: EdgeInsets.all(48),
                            child: Text('这一页还没有书籍'),
                          ),
                        if (widget.ranking)
                          ...result.books.indexed.map(
                            (entry) => InkWell(
                              onTap: () =>
                                  showBook(context, widget.store, entry.$2),
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                  26,
                                  5,
                                  26,
                                  22,
                                ),
                                child: Row(
                                  children: [
                                    SizedBox(
                                      width: 34,
                                      child: Text(
                                        '${(page - 1) * 10 + entry.$1 + 1}'
                                            .padLeft(2, '0'),
                                        style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w300,
                                          color: entry.$1 < 3 && page == 1
                                              ? Theme.of(
                                                  context,
                                                ).colorScheme.primary
                                              : muted,
                                        ),
                                      ),
                                    ),
                                    BookCover(entry.$2, width: 74, height: 104),
                                    const SizedBox(width: 19),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            entry.$2.title,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              fontSize: 15,
                                              height: 1.5,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          const SizedBox(height: 6),
                                          Text(
                                            entry.$2.author,
                                            style: const TextStyle(
                                              color: muted,
                                              fontSize: 12,
                                            ),
                                          ),
                                          const SizedBox(height: 10),
                                          Text(
                                            '${prettyCount(entry.$2.hits)} 次阅读 · ${prettyCount(entry.$2.favorites)} 人收藏',
                                            style: const TextStyle(
                                              color: muted,
                                              fontSize: 10,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        else
                          BookCollection(
                            widget.store,
                            result.books,
                            (n) => showBook(context, widget.store, n),
                          ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(26, 4, 26, 26),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              OutlinedButton(
                                onPressed: page > 1
                                    ? () => changePage(page - 1)
                                    : null,
                                child: const Text('上一页'),
                              ),
                              const SizedBox(width: 20),
                              Text(
                                '$page',
                                style: const TextStyle(color: muted),
                              ),
                              const SizedBox(width: 20),
                              OutlinedButton(
                                onPressed: page < result.pages
                                    ? () => changePage(page + 1)
                                    : null,
                                child: const Text('下一页'),
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}

class ShelfScreen extends StatefulWidget {
  final ReaderStore store;
  const ShelfScreen(this.store, {super.key});
  @override
  State<ShelfScreen> createState() => _ShelfScreenState();
}

class _ShelfScreenState extends State<ShelfScreen> {
  int filter = 0;
  bool busy = false;
  Future<void> sync() async {
    if (widget.store.username.isEmpty) {
      await Navigator.push(
        context,
        MaterialPageRoute<void>(builder: (_) => LoginScreen(widget.store)),
      );
      if (widget.store.username.isEmpty) return;
    }
    setState(() => busy = true);
    try {
      final ids = await widget.store.api.cloudShelf();
      for (final id in ids) {
        if (!widget.store.contains(id)) {
          await widget.store.add(await widget.store.api.detail(id));
        }
      }
      if (mounted) tell(context, '已导入云端 ${ids.length} 本书');
    } catch (e) {
      if (mounted) tell(context, '$e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: widget.store,
    builder: (context, _) {
      final books = filter == 0
          ? widget.store.shelf
          : widget.store.shelf
                .where((n) => widget.store.record(n.id) != null)
                .toList();
      if (filter == 1) {
        books.sort(
          (a, b) => '${widget.store.record(b.id)?['time']}'.compareTo(
            '${widget.store.record(a.id)?['time']}',
          ),
        );
      }
      return WidthLimit(
        Column(
          children: [
            PageHeading(
              '我的书架',
              '${widget.store.shelf.length} 本收藏 · 接着上次的故事',
              actions: [
                BookViewToggle(widget.store),
                IconButton(
                  tooltip: '导入云书架',
                  onPressed: busy ? null : sync,
                  icon: busy
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.cloud_sync_outlined),
                ),
              ],
            ),
            FilterStrip(
              const ['全部收藏', '最近阅读'],
              filter,
              (i) => setState(() => filter = i),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: books.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(28),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.bookmarks_outlined,
                              size: 44,
                              color: muted,
                            ),
                            const SizedBox(height: 22),
                            Text(
                              filter == 0 ? '书架为空' : '暂无阅读记录',
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 24),
                            OutlinedButton(
                              onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute<void>(
                                  builder: (_) => SearchScreen(widget.store),
                                ),
                              ),
                              child: const Text('搜索小说'),
                            ),
                          ],
                        ),
                      ),
                    )
                  : ListView(
                      children: [
                        BookCollection(
                          widget.store,
                          books,
                          (n) => showBook(context, widget.store, n),
                          caption: (n) =>
                              widget.store.record(n.id)?['title'] as String? ??
                              n.author,
                        ),
                      ],
                    ),
            ),
          ],
        ),
      );
    },
  );
}

class SearchScreen extends StatefulWidget {
  final ReaderStore store;
  const SearchScreen(this.store, {super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final controller = TextEditingController();
  Future<BookPage>? future;
  int type = 0;
  String query = '';
  void search([String? input]) {
    final value = (input ?? controller.text).trim();
    if (value.isEmpty) return;
    controller.text = value;
    FocusScope.of(context).unfocus();
    widget.store.searched(value);
    setState(() {
      query = value;
      future = widget.store.api.search(
        value,
        type == 0 ? 'articlename' : 'author',
      );
    });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('搜索'),
      actions: [BookViewToggle(widget.store)],
    ),
    body: SafeArea(
      child: WidthLimit(
        Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(26, 12, 26, 20),
              child: TextField(
                key: const ValueKey('search_input'),
                controller: controller,
                autofocus: true,
                textInputAction: TextInputAction.search,
                onSubmitted: search,
                decoration: InputDecoration(
                  hintText: '书名或作者',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: IconButton(
                    tooltip: '搜索',
                    onPressed: search,
                    icon: const Icon(Icons.arrow_forward),
                  ),
                ),
              ),
            ),
            FilterStrip(const ['按书名', '按作者'], type, (i) {
              setState(() => type = i);
              if (query.isNotEmpty) search(query);
            }),
            Expanded(
              child: future == null
                  ? ListView(
                      padding: const EdgeInsets.all(26),
                      children: [
                        Row(
                          children: [
                            const Text(
                              '搜索记录',
                              style: TextStyle(color: muted, fontSize: 12),
                            ),
                            const Spacer(),
                            if (widget.store.history.isNotEmpty)
                              TextButton(
                                onPressed: () {
                                  widget.store.history.clear();
                                  widget.store.save();
                                  setState(() {});
                                },
                                child: const Text('清空'),
                              ),
                          ],
                        ),
                        const SizedBox(height: 18),
                        Wrap(
                          spacing: 12,
                          runSpacing: 12,
                          children: [
                            for (final key in widget.store.history)
                              ActionChip(
                                label: Text(key),
                                onPressed: () => search(key),
                              ),
                          ],
                        ),
                      ],
                    )
                  : FutureBuilder<BookPage>(
                      future: future,
                      builder: (context, snapshot) {
                        if (snapshot.connectionState != ConnectionState.done) {
                          return const LoadingView();
                        }
                        if (snapshot.hasError) {
                          return FailureView(
                            snapshot.error!,
                            () => search(query),
                          );
                        }
                        final books = snapshot.data!.books;
                        return ListView(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(26),
                              child: Text(
                                '“$query” · ${books.length} 本结果',
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: muted,
                                ),
                              ),
                            ),
                            if (books.isEmpty)
                              const Padding(
                                padding: EdgeInsets.all(48),
                                child: Center(child: Text('没有找到，试试更短的关键词。')),
                              )
                            else
                              BookCollection(
                                widget.store,
                                books,
                                (n) => showBook(context, widget.store, n),
                              ),
                          ],
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    ),
  );
}

class DetailScreen extends StatefulWidget {
  final ReaderStore store;
  final Novel initial;
  const DetailScreen(this.store, this.initial, {super.key});
  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  late Novel book = widget.initial;
  List<Chapter>? chapters;
  String intro = '';
  Object? error;
  bool loading = true, downloading = false, cancel = false;
  int downloaded = 0, downloadTotal = 0;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      error = null;
      loading = true;
    });
    try {
      final results = await Future.wait<Object>([
        widget.store.api.detail(book.id),
        widget.store.api.intro(book.id),
        widget.store.api.catalog(book.id),
      ]);
      if (!mounted) return;
      setState(() {
        book = results[0] as Novel;
        intro = results[1] as String;
        chapters = results[2] as List<Chapter>;
        loading = false;
      });
    } catch (e) {
      try {
        chapters = await widget.store.api.catalog(book.id);
      } catch (_) {}
      if (mounted) {
        setState(() {
          loading = false;
          error = e;
        });
      }
    }
  }

  Future<void> read([int? index]) async {
    if (chapters == null || chapters!.isEmpty) {
      tell(context, '目录还没有加载完成');
      return;
    }
    var start =
        index ??
        chapters!.indexWhere(
          (c) => c.id == widget.store.record(book.id)?['cid'],
        );
    if (start < 0) start = 0;
    await Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => ReaderScreen(widget.store, book, chapters!, start),
      ),
    );
    if (mounted) setState(() {});
  }

  Future<void> download() async {
    if (chapters == null || chapters!.isEmpty) return;
    final volumes = chapters!.map((c) => c.volume).toSet().toList();
    final selection = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * .65,
          child: Column(
            children: [
              const Padding(
                padding: EdgeInsets.all(22),
                child: Text(
                  '缓存到本地',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18),
                ),
              ),
              Expanded(
                child: ListView(
                  children: [
                    ListTile(
                      title: const Text('全书'),
                      subtitle: Text('${chapters!.length} 个章节'),
                      trailing: const Icon(Icons.download_outlined),
                      onTap: () => Navigator.pop(context, '__all__'),
                    ),
                    for (final volume in volumes)
                      ListTile(
                        title: Text(volume),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => Navigator.pop(context, volume),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (selection == null || !mounted) return;
    final items = selection == '__all__'
        ? chapters!
        : chapters!.where((c) => c.volume == selection).toList();
    await widget.store.add(book);
    if (!mounted) return;
    setState(() {
      downloading = true;
      cancel = false;
      downloaded = 0;
      downloadTotal = items.length;
    });
    try {
      for (final chapter in items) {
        if (cancel || !mounted) break;
        final text = await widget.store.api.text(book.id, chapter.id);
        final urls = parseReadingContent(
          text,
        ).map((b) => b.imageUrl).whereType<String>();
        for (final url in urls) {
          if (cancel || !mounted) break;
          await widget.store.api.image(url);
        }
        if (mounted) setState(() => downloaded++);
      }
      if (mounted) tell(context, cancel ? '已停止，完成的章节已保留' : '缓存完成，可离线阅读');
    } catch (e) {
      if (mounted) tell(context, '已保存 $downloaded 个章节。$e');
    } finally {
      if (mounted) setState(() => downloading = false);
    }
  }

  @override
  void dispose() {
    cancel = true;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('小说详情'),
      actions: [
        IconButton(
          tooltip: '书评',
          icon: const Icon(Icons.forum_outlined),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute<void>(
              builder: (_) => ReviewsScreen(widget.store, book.id, book.title),
            ),
          ),
        ),
        PopupMenuButton<String>(
          onSelected: (value) async {
            try {
              if (value == 'refresh') {
                if (chapters != null) {
                  chapters = await widget.store.api.catalog(
                    book.id,
                    refresh: true,
                  );
                }
                await load();
              }
              if (value == 'cloud') {
                await widget.store.api.cloudAdd(book.id);
                if (context.mounted) tell(context, '已加入云书架');
              }
              if (value == 'cloud_remove') {
                await widget.store.api.cloudDelete(book.id);
                if (context.mounted) tell(context, '已从云书架移除');
              }
            } catch (e) {
              if (context.mounted) tell(context, '$e');
            }
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'refresh', child: Text('检查更新')),
            PopupMenuItem(value: 'cloud', child: Text('加入云书架')),
            PopupMenuItem(value: 'cloud_remove', child: Text('从云书架移除')),
          ],
        ),
      ],
    ),
    body: WidthLimit(
      ListView(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(26, 22, 26, 26),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BookCover(book, width: 112, height: 160),
                const SizedBox(width: 22),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        book.title,
                        style: const TextStyle(
                          fontSize: 22,
                          height: 1.4,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        book.author,
                        style: const TextStyle(fontSize: 14, color: muted),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        [
                          book.publisher,
                          book.status,
                        ].where((s) => s.isNotEmpty).join(' · '),
                        style: const TextStyle(fontSize: 11, color: muted),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '更新于 ${book.updated}',
                        style: const TextStyle(fontSize: 11, color: muted),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 26),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final tag
                    in book.tags
                        .split(RegExp(r'\s+'))
                        .where((e) => e.isNotEmpty))
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: Theme.of(
                        context,
                      ).colorScheme.onSurface.withValues(alpha: .045),
                      borderRadius: BorderRadius.circular(3),
                    ),
                    child: Text(
                      tag,
                      style: const TextStyle(fontSize: 10, color: muted),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(26),
            child: Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    key: const ValueKey('start_reading'),
                    onPressed: chapters == null ? null : () => read(),
                    icon: const Icon(Icons.menu_book_outlined, size: 19),
                    label: Text(
                      widget.store.record(book.id) == null ? '开始阅读' : '继续阅读',
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ListenableBuilder(
                    listenable: widget.store,
                    builder: (context, _) => OutlinedButton.icon(
                      onPressed: () async {
                        if (widget.store.contains(book.id)) {
                          await widget.store.remove(book.id);
                        } else {
                          await widget.store.add(book);
                        }
                      },
                      icon: Icon(
                        widget.store.contains(book.id)
                            ? Icons.bookmark
                            : Icons.bookmark_border,
                        size: 18,
                      ),
                      label: Text(
                        widget.store.contains(book.id) ? '已在书架' : '加入书架',
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (downloading)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 26),
              child: Column(
                children: [
                  LinearProgressIndicator(value: downloaded / downloadTotal),
                  Row(
                    children: [
                      Text(
                        '正在缓存 $downloaded / $downloadTotal',
                        style: const TextStyle(fontSize: 12, color: muted),
                      ),
                      const Spacer(),
                      TextButton(
                        onPressed: () => cancel = true,
                        child: const Text('停止'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          if (loading)
            const LoadingView()
          else if (error != null)
            FailureView(error!, load),
          if (intro.isNotEmpty || book.intro.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(26, 0, 26, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '故事简介',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 16),
                  SelectableText(
                    intro.isEmpty ? book.intro : intro,
                    style: const TextStyle(fontSize: 14, height: 1.9),
                  ),
                ],
              ),
            ),
          if (chapters != null && chapters!.isNotEmpty) ...[
            const Divider(indent: 26, endIndent: 26),
            Padding(
              padding: const EdgeInsets.fromLTRB(26, 16, 18, 10),
              child: Row(
                children: [
                  const Text(
                    '目录',
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    '${chapters!.length} 章',
                    style: const TextStyle(fontSize: 11, color: muted),
                  ),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: downloading ? null : download,
                    icon: const Icon(Icons.download_outlined, size: 17),
                    label: const Text('缓存'),
                  ),
                ],
              ),
            ),
            for (final volume in chapters!.map((e) => e.volume).toSet())
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Theme(
                  data: Theme.of(
                    context,
                  ).copyWith(dividerColor: Colors.transparent),
                  child: ExpansionTile(
                    initiallyExpanded: volume == chapters!.first.volume,
                    tilePadding: const EdgeInsets.symmetric(horizontal: 10),
                    title: Text(
                      volume,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    subtitle: Text(
                      '${chapters!.where((c) => c.volume == volume).length} 个章节',
                      style: const TextStyle(color: muted, fontSize: 10),
                    ),
                    children: [
                      for (final entry in chapters!.indexed.where(
                        (e) => e.$2.volume == volume,
                      ))
                        FutureBuilder<bool>(
                          future: widget.store.api.isCached(
                            book.id,
                            entry.$2.id,
                          ),
                          builder: (context, snapshot) => ListTile(
                            dense: true,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 20,
                            ),
                            title: Text(
                              entry.$2.title,
                              style: const TextStyle(fontSize: 13, height: 1.6),
                            ),
                            trailing: snapshot.data == true
                                ? const Icon(
                                    Icons.offline_pin_outlined,
                                    size: 15,
                                    color: muted,
                                  )
                                : const Icon(
                                    Icons.chevron_right,
                                    size: 17,
                                    color: muted,
                                  ),
                            onTap: () => read(entry.$1),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 35),
          ],
        ],
      ),
    ),
  );
}
