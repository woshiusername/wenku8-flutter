import 'package:xml/xml.dart';

String dataValue(XmlElement element, String name) {
  final fields = element
      .findElements('data')
      .where((e) => e.getAttribute('name') == name);
  if (fields.isEmpty) return '';
  final field = fields.first;
  return (field.getAttribute('value') ?? field.innerText).trim();
}

class Novel {
  final int id;
  final String title, author, status, updated, tags, intro, publisher;
  final int hits, favorites, length;
  const Novel({
    required this.id,
    required this.title,
    this.author = '',
    this.status = '',
    this.updated = '',
    this.tags = '',
    this.intro = '',
    this.publisher = '',
    this.hits = 0,
    this.favorites = 0,
    this.length = 0,
  });
  String get cover =>
      'https://img.wenku8.com/image/${id ~/ 1000}/$id/${id}s.jpg';
  factory Novel.fromXml(XmlElement e, {int? id}) => Novel(
    id:
        id ??
        int.tryParse(e.getAttribute('aid') ?? '') ??
        int.tryParse(e.findElements('data').first.getAttribute('aid') ?? '') ??
        0,
    title: dataValue(e, 'Title'),
    author: dataValue(e, 'Author'),
    status: dataValue(e, 'BookStatus'),
    updated: dataValue(e, 'LastUpdate'),
    tags: dataValue(e, 'Tags'),
    intro: dataValue(e, 'IntroPreview'),
    publisher: dataValue(e, 'PressId'),
    hits: int.tryParse(dataValue(e, 'TotalHitsCount')) ?? 0,
    favorites: int.tryParse(dataValue(e, 'FavCount')) ?? 0,
    length: int.tryParse(dataValue(e, 'BookLength')) ?? 0,
  );
  factory Novel.fromJson(Map<String, dynamic> j) => Novel(
    id: j['id'] as int,
    title: j['title'] as String,
    author: j['author'] ?? '',
    status: j['status'] ?? '',
    updated: j['updated'] ?? '',
    tags: j['tags'] ?? '',
    intro: j['intro'] ?? '',
    publisher: j['publisher'] ?? '',
    hits: j['hits'] ?? 0,
    favorites: j['favorites'] ?? 0,
    length: j['length'] ?? 0,
  );
  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'author': author,
    'status': status,
    'updated': updated,
    'tags': tags,
    'intro': intro,
    'publisher': publisher,
    'hits': hits,
    'favorites': favorites,
    'length': length,
  };
}

class BookPage {
  final List<Novel> books;
  final int pages;
  BookPage(this.books, this.pages);
  factory BookPage.parse(String text) {
    final doc = XmlDocument.parse(text);
    final page = doc.findAllElements('page').firstOrNull;
    return BookPage(
      doc
          .findAllElements('item')
          .where((e) => e.getAttribute('aid') != null)
          .map(Novel.fromXml)
          .toList(),
      int.tryParse(page?.getAttribute('num') ?? '') ?? 1,
    );
  }
}

class Chapter {
  final int id;
  final String title, volume;
  const Chapter(this.id, this.title, this.volume);
}

List<Chapter> parseCatalog(String text) {
  final doc = XmlDocument.parse(text);
  final chapters = <Chapter>[];
  for (final volume in doc.findAllElements('volume')) {
    final name = volume.children
        .whereType<XmlCDATA>()
        .map((e) => e.value)
        .join()
        .trim();
    for (final c in volume.findElements('chapter')) {
      final id = int.tryParse(c.getAttribute('cid') ?? '');
      if (id != null) chapters.add(Chapter(id, c.innerText.trim(), name));
    }
  }
  return chapters;
}

class Review {
  final int id, replies;
  final String user, content, date;
  const Review(this.id, this.replies, this.user, this.content, this.date);
  static List<Review> parse(String text) => XmlDocument.parse(text)
      .findAllElements('item')
      .map(
        (e) => Review(
          int.tryParse(e.getAttribute('rid') ?? '') ?? 0,
          int.tryParse(e.getAttribute('replies') ?? '') ?? 0,
          e.findElements('user').firstOrNull?.innerText ?? '',
          e.findElements('content').firstOrNull?.innerText.trim() ?? '',
          e.getAttribute('posttime') ?? e.getAttribute('timestamp') ?? '',
        ),
      )
      .toList();
  String get displayDate => date.length >= 8
      ? '${date.substring(0, 4)}.${date.substring(4, 6)}.${date.substring(6, 8)}'
      : date;
}
