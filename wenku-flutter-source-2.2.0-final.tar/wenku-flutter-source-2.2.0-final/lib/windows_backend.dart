import 'dart:convert';
import 'dart:ffi';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:ffi/ffi.dart';
import 'package:flutter/services.dart';

/// Compatibility with Wenku8 1.30: HMAC over the version and UTC minute bucket.
/// Confirmed against the original supplied JNI binary; no phone is needed.
String windowsVersionToken(DateTime time) {
  final bucket = time.millisecondsSinceEpoch ~/ 60000;
  final digest = Hmac(
    sha256,
    utf8.encode('digital-bento'),
  ).convert(utf8.encode('1.30|digital-bento|$bucket')).toString();
  return '1.30-digital-bento-${digest.substring(12, 20)}';
}

final class _Blob extends Struct {
  @Uint32()
  external int size;
  external Pointer<Uint8> bytes;
}

typedef _CryptNative =
    Int32 Function(
      Pointer<_Blob>,
      Pointer<Void>,
      Pointer<_Blob>,
      Pointer<Void>,
      Pointer<Void>,
      Uint32,
      Pointer<_Blob>,
    );
typedef _CryptDart =
    int Function(
      Pointer<_Blob>,
      Pointer<Void>,
      Pointer<_Blob>,
      Pointer<Void>,
      Pointer<Void>,
      int,
      Pointer<_Blob>,
    );

class WindowsServices {
  final kernel = DynamicLibrary.open('kernel32.dll');
  final crypt = DynamicLibrary.open('crypt32.dll');
  List<int> protect(List<int> bytes, {bool decrypt = false}) {
    final input = calloc<_Blob>(), output = calloc<_Blob>();
    final buffer = calloc<Uint8>(bytes.length);
    buffer.asTypedList(bytes.length).setAll(0, bytes);
    input.ref
      ..size = bytes.length
      ..bytes = buffer;
    try {
      final fn = crypt.lookupFunction<_CryptNative, _CryptDart>(
        decrypt ? 'CryptUnprotectData' : 'CryptProtectData',
      );
      if (fn(input, nullptr, nullptr, nullptr, nullptr, 1, output) == 0) {
        throw StateError('Windows session encryption failed');
      }
      return List<int>.of(output.ref.bytes.asTypedList(output.ref.size));
    } finally {
      if (output.ref.bytes != nullptr) {
        kernel.lookupFunction<
          Pointer<Void> Function(Pointer<Void>),
          Pointer<Void> Function(Pointer<Void>)
        >('LocalFree')(output.ref.bytes.cast());
      }
      calloc.free(buffer);
      calloc.free(input);
      calloc.free(output);
    }
  }

  String encodeGbk(String text) {
    final fn = kernel
        .lookupFunction<
          Int32 Function(
            Uint32,
            Uint32,
            Pointer<Utf16>,
            Int32,
            Pointer<Uint8>,
            Int32,
            Pointer<Void>,
            Pointer<Void>,
          ),
          int Function(
            int,
            int,
            Pointer<Utf16>,
            int,
            Pointer<Uint8>,
            int,
            Pointer<Void>,
            Pointer<Void>,
          )
        >('WideCharToMultiByte');
    final source = text.toNativeUtf16();
    try {
      final size = fn(
        936,
        0,
        source,
        text.length,
        nullptr,
        0,
        nullptr,
        nullptr,
      );
      final buffer = calloc<Uint8>(size);
      try {
        if (size > 0 &&
            fn(936, 0, source, text.length, buffer, size, nullptr, nullptr) ==
                0) {
          throw StateError('GBK conversion failed');
        }
        final encoded = StringBuffer();
        for (final byte in buffer.asTypedList(size)) {
          if ((byte >= 65 && byte <= 90) ||
              (byte >= 97 && byte <= 122) ||
              (byte >= 48 && byte <= 57) ||
              [45, 95, 46, 42].contains(byte)) {
            encoded.writeCharCode(byte);
          } else if (byte == 32) {
            encoded.write('+');
          } else {
            encoded.write(
              '%${byte.toRadixString(16).toUpperCase().padLeft(2, '0')}',
            );
          }
        }
        return base64Encode(utf8.encode(encoded.toString()));
      } finally {
        calloc.free(buffer);
      }
    } finally {
      calloc.free(source);
    }
  }

  void keepAwake(bool enabled) {
    kernel.lookupFunction<Uint32 Function(Uint32), int Function(int)>(
      'SetThreadExecutionState',
    )(enabled ? 0x80000003 : 0x80000000);
  }

  void openUrl(String url) {
    if (!url.startsWith('https://')) {
      throw ArgumentError('Only HTTPS URLs are supported');
    }
    final shell = DynamicLibrary.open('shell32.dll');
    final fn = shell
        .lookupFunction<
          IntPtr Function(
            IntPtr,
            Pointer<Utf16>,
            Pointer<Utf16>,
            Pointer<Utf16>,
            Pointer<Utf16>,
            Int32,
          ),
          int Function(
            int,
            Pointer<Utf16>,
            Pointer<Utf16>,
            Pointer<Utf16>,
            Pointer<Utf16>,
            int,
          )
        >('ShellExecuteW');
    final operation = 'open'.toNativeUtf16(), target = url.toNativeUtf16();
    try {
      if (fn(0, operation, target, nullptr, nullptr, 1) <= 32) {
        throw StateError('Unable to open the browser');
      }
    } finally {
      calloc.free(operation);
      calloc.free(target);
    }
  }
}

class WindowsBackend {
  final Directory directory;
  final services = WindowsServices();
  String session = '';
  Future<void>? ready;
  Future<void> pendingSession = Future.value();
  WindowsBackend({Directory? dataDirectory})
    : directory =
          dataDirectory ??
          Directory(
            '${Platform.environment['LOCALAPPDATA'] ?? Platform.environment['APPDATA']}/Wenku',
          );
  File get sessionFile => File('${directory.path}/session.bin');
  Future<void> init() => ready ??= initialize();
  Future<void> initialize() async {
    await directory.create(recursive: true);
    if (await sessionFile.exists()) {
      try {
        session = utf8.decode(
          services.protect(await sessionFile.readAsBytes(), decrypt: true),
        );
      } catch (_) {
        session = '';
      }
    }
  }

  Future<void> persistSession(String value) {
    session = value;
    pendingSession = pendingSession.catchError((_) {}).then((_) async {
      if (value.isEmpty) {
        if (await sessionFile.exists()) await sessionFile.delete();
      } else {
        final temporary = File('${sessionFile.path}.tmp');
        await temporary.writeAsBytes(
          services.protect(utf8.encode(value)),
          flush: true,
        );
        await temporary.rename(sessionFile.path);
      }
    });
    return pendingSession;
  }

  Future<dynamic> invoke(String method, Map<String, dynamic> arguments) async {
    await init();
    try {
      switch (method) {
        case 'storagePath':
          return directory.path;
        case 'hasSession':
          return session.isNotEmpty;
        case 'clearSession':
          await persistSession('');
          return null;
        case 'encodeGbk':
          return services.encodeGbk(arguments['text'] as String? ?? '');
        case 'keepAwake':
          services.keepAwake(arguments['enabled'] == true);
          return null;
        case 'openUrl':
          services.openUrl(arguments['url'] as String);
          return null;
        case 'request':
          return await request(arguments['action'] as String);
        default:
          throw UnsupportedError(method);
      }
    } catch (e) {
      throw PlatformException(code: 'NETWORK', message: e.toString());
    }
  }

  Future<Map<String, dynamic>> request(String action) async {
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 12)
      ..userAgent = 'Dalvik/2.1.0';
    try {
      final now = DateTime.now();
      final body =
          '&appver=${windowsVersionToken(now)}&request=${base64Encode(utf8.encode(action))}&timetoken=${now.millisecondsSinceEpoch}';
      final request = await client.postUrl(
        Uri.parse('https://wenku8-relay.mewx.org/'),
      );
      request.headers.contentType = ContentType(
        'application',
        'x-www-form-urlencoded',
      );
      if (session.isNotEmpty) request.cookies.add(Cookie('PHPSESSID', session));
      request.add(utf8.encode(body));
      final response = await request.close().timeout(
        const Duration(seconds: 25),
      );
      final bytes = await response
          .fold<List<int>>([], (result, b) => result..addAll(b))
          .timeout(const Duration(seconds: 25));
      if (response.statusCode == 200) {
        for (final cookie in response.cookies) {
          if (cookie.name == 'PHPSESSID') await persistSession(cookie.value);
        }
      }
      return {'status': response.statusCode, 'text': utf8.decode(bytes)};
    } finally {
      client.close();
    }
  }
}
