import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'api.dart';
import 'models.dart';

enum ReadingMode { scroll, horizontal, vertical }

extension ReadingModeLabel on ReadingMode {
  String get label => switch (this) {
    ReadingMode.scroll => '上下滚动',
    ReadingMode.horizontal => '左右翻页',
    ReadingMode.vertical => '竖排 · 右起',
  };
}

class ReaderStore extends ChangeNotifier {
  final WenkuApi api;
  ReaderStore(this.api);
  List<Novel> shelf = [];
  List<String> history = [];
  Map<String, dynamic> progress = {};
  String username = '';
  bool dark = false;
  double fontSize = 20, lineHeight = 1.85;
  int paper = 0;
  bool keepAwake = true;
  ReadingMode readingMode = ReadingMode.scroll;
  bool bookList = true;
  bool get horizontalReading => readingMode == ReadingMode.horizontal;
  set horizontalReading(bool value) =>
      readingMode = value ? ReadingMode.horizontal : ReadingMode.scroll;
  bool get pagedReading => readingMode != ReadingMode.scroll;
  File? file;
  Future<void> init() async {
    await api.init();
    file = File('${api.cache!.parent.path}/reader_state.json');
    if (await file!.exists()) {
      try {
        final j =
            jsonDecode(await file!.readAsString()) as Map<String, dynamic>;
        shelf = (j['shelf'] as List? ?? [])
            .map((e) => Novel.fromJson(Map<String, dynamic>.from(e)))
            .toList();
        history = List<String>.from(j['history'] ?? []);
        progress = Map<String, dynamic>.from(j['progress'] ?? {});
        username = j['username'] ?? '';
        dark = j['dark'] ?? false;
        fontSize = (j['fontSize'] as num? ?? 20).toDouble();
        lineHeight = (j['lineHeight'] as num? ?? 1.85).toDouble();
        paper = j['paper'] ?? 0;
        keepAwake = j['keepAwake'] ?? true;
        readingMode =
            ReadingMode.values
                .where((m) => m.name == j['readingMode'])
                .firstOrNull ??
            ((j['horizontalReading'] ?? false)
                ? ReadingMode.horizontal
                : ReadingMode.scroll);
        bookList = j['bookList'] ?? true;
        api.language = j['language'] ?? 0;
      } catch (_) {
        /* Keep defaults if a state file is damaged. */
      }
    }
  }

  Future<void> _pending = Future.value();
  Future<void> save() {
    final content = jsonEncode({
      'shelf': shelf.map((e) => e.toJson()).toList(),
      'history': history,
      'progress': progress,
      'username': username,
      'dark': dark,
      'fontSize': fontSize,
      'lineHeight': lineHeight,
      'paper': paper,
      'keepAwake': keepAwake,
      'horizontalReading': horizontalReading,
      'readingMode': readingMode.name,
      'bookList': bookList,
      'language': api.language,
    });
    _pending = _pending.catchError((_) {}).then((_) async {
      if (file != null) {
        final temp = File('${file!.path}.tmp');
        await temp.writeAsString(content, flush: true);
        await temp.rename(file!.path);
      }
    });
    notifyListeners();
    return _pending;
  }

  bool contains(int id) => shelf.any((n) => n.id == id);
  Future<void> add(Novel novel) async {
    shelf.removeWhere((n) => n.id == novel.id);
    shelf.insert(0, novel);
    await save();
  }

  Future<void> remove(int id) async {
    shelf.removeWhere((n) => n.id == id);
    await save();
  }

  Map<String, dynamic>? record(int id) => progress['$id'] is Map
      ? Map<String, dynamic>.from(progress['$id'])
      : null;
  Future<void> remember(
    Novel novel,
    Chapter chapter,
    double offset, {
    double? fraction,
    bool horizontal = false,
  }) async {
    progress['${novel.id}'] = {
      'cid': chapter.id,
      'title': chapter.title,
      'offset': offset,
      if (fraction != null) 'fraction': fraction,
      'horizontal': horizontal,
      'readingMode': readingMode.name,
      'time': DateTime.now().toIso8601String(),
    };
    await save();
  }

  Future<void> searched(String key) async {
    history.remove(key);
    history.insert(0, key);
    if (history.length > 12) history.removeLast();
    await save();
  }
}
